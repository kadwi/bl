# -*- coding: utf-8 -*-
#thanks to GREET OLALA

from linepy import *
from akad.ttypes import Message
from akad.ttypes import ContentType as Type
from akad.ttypes import ChatRoomAnnouncementContents
from akad.ttypes import ChatRoomAnnouncement
from thrift import transport, protocol, server
from datetime import datetime, timedelta
import pytz, pafy, livejson, time, asyncio, random, multiprocessing, timeit, sys, json, ctypes, tweepy, codecs, threading, glob, re, ast, six, os, subprocess, wikipedia, atexit, goslate, urllib, urllib.parse, urllib3, string, tempfile, shutil, unicodedata
from humanfriendly import format_timespan, format_size, format_number, format_length
import html5lib
import requests,json,urllib3
from random import randint
from bs4 import BeautifulSoup
from gtts import gTTS
from googletrans import Translator
import youtube_dl
from time import sleep
import pyimgflip
from zalgo_text import zalgo
from threading import Thread,Event
import requests,uvloop
import wikipedia as wiki
requests.packages.urllib3.disable_warnings()
loop = uvloop.new_event_loop()


cl = LINE("bhfahmi050@gmail.com","cewekmatre01")
cl.log("Auth Token : " + str(cl.authToken))

#========{{KICKER ANTIJS}}========#
k1 = LINE("wku45758@bcaoo.com","cewekmatre01")
k1.log("Auth Token : " + str(k1.authToken))

k2 = LINE("ces436347@gmail.com","cewekmatre01")
k2.log("Auth Token : " + str(k2.authToken))

sw = LINE("greensop834@gmail.com","cewekmatre01")
sw.log("Auth Token : " + str(sw.authToken))
#==========GREET_TEMPLATE========
print ("♒♒♒♒♒♒♒🔰🔰♒♒♒♒♒♒♒")
print ("================================")
print ("┌──────────────────┐\n│  ⬜ OPEN ORDER ⬜ \n├──────────────────\n│🎧FITUR LINE & SMULE🎤\n├──────────────────\n┝[🛡️]►Coin Line\n┝[🛡️]►Coin Gift\n┝[🛡️]►Vip Smule Android\n┝[🛡️]►Beku Akun Smule\n┝[🛡️]►Follower Smule\n┝[🛡️]►Songbook Smule\n│☛🏧Via Bank & Pulsa📱\n│♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛\n├──────────────────\n│⚙️PROTECT & SELFBOT 🔧\n├──────────────────\n┝[🛡️]►Selfbot Only\n┝[🛡️]►Selfbot Only + Ajs\n┝[🛡️]►Selfbot Template\n┝[🛡️]►Selfbot Template + Ajs\n┝[🛡️]►Bot Protect Rom Smule\n┝[🛡️]►Bot Protect Rom Event\n│☛If Order Creator\n│WA: 082135759022\n│♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛\n├──────────────────\n│Suport:⭕GʀᴇᴛSʜᴏᴘ⭕\n└──────────────────")
print ("================================")
print("╔•══════════════════════\n╠•☛LOGIN TEMPLATE SUKSES\n╚•══════════════════════")
print ("♒♒♒♒♒♒♒🔰🔰♒♒♒♒♒♒♒")


oepoll = OEPoll(cl)
call = cl
creator = ["u18dbd775ada2eb468d1134caf7073478"]
owner = ["u18dbd775ada2eb468d1134caf7073478"]
admin = ["u9e7b95e0fe30d1b8a23a6c83e73a5d8f"]
staff = ["u9e7b95e0fe30d1b8a23a6c83e73a5d8f"]
Tumbal = ["ua5b8674e4136ccf8daf3c05f418a7c41","ufcea91f89f2d28e1a9227231b9f37167","ua86e5df7f2ec721380de338f325a957b","u54dc188d34f4853458adcd7a8c347030"]

lineProfile = cl.getProfile()
mid = cl.getProfile().mid
Amid = k1.getProfile().mid
Bmid = k2.getProfile().mid
Zmid = sw.getProfile().mid
KAC = [cl,k1,k2,sw]
Bots = [mid,Amid,Bmid,Zmid]
Saints = admin + owner + staff
Team = creator + owner + admin + staff + Bots
Setbot = codecs.open("setting.json","r","utf-8")
Setmain = json.load(Setbot)
protectantijs = []
protectcancel = []
protectqr = []
protectkick = []
protectjoin = []
protectinvite = []
welcome = []
targets = []
protectname = []
prohibitedWords = ['Asu', 'Jancuk', 'Tai', 'Kickall', 'Ratakan', 'Cleanse']
userTemp = {}
userKicked = []
msg_dict = {}
msg_dict1 = {}
dt_to_str = {}
temp_flood = {}
groupName = {}
groupImage = {}
list = []
ban_list = []
warmode = []
ghost = []
offbot = []

settings = {
    "welcome": False,
    "leave": False,
    "mid": False,
    "Aip": True,
    "replySticker": False,
    "stickerOn": False,
    "checkContact": False,
    "postEndUrl": {},
    "postingan":{},
    "checkPost": False,
    "autoRead": False,
    "autoJoinTicket": False,
    "setKey": False,
    "restartPoint": False,
    "checkSticker": False,
    "userMentioned": False,
    "messageSticker": False,
    "changeGroupPicture": [],
    "keyCommand": "",
    "AddstickerTag": {
        "sid": "",
        "spkg": "",
        "status": False
            },
    "Addsticker":{
            "name": "",
            "status":False
            },
    "stk":{},
    "selfbot":True,
    "Images":{},
    "Img":{},
    "Addimage":{
            "name": "",
            "status":False
            },
    "Videos":{},
    "Addaudio":{
            "name": "",
            "status":False
            },
    "Addvideo":{
            "name": "",
            "status":False
            },
    "myProfile": {
        "displayName": "",
        "coverId": "",
        "pictureStatus": "",
        "statusMessage": ""
    },
    "mimic": {
        "copy": False,
        "status": False,
        "target": {}
    }, 
    "unsendMessage": False,
    "Picture":False,
    "group":{},
    "groupPicture":False,
    "changevp": False,
    "changeCover":False,
    "changePicture":False,
    "changeProfileVideo": False,
    "ChangeVideoProfilevid":{},
    "ChangeVideoProfilePicture":{},
    "displayName": "",
    "userAgent": [
        "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)",
        "Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.200.32.99 Safari/537.36"
    ]
}

wait = {
    "limit": 2,
    "owner":{},
    "admin":{},
    "addadmin":False,
    "delladmin":False,
    "checkmid": False,
    "getMid": False,
    "invite":False,
    "Invi":False,
    "staff":{},
    "Timeline": False,
    "likePost": False,
    "likeOn": True,
    "addstaff":False,
    "dellstaff":False,
    "bots":{},
    "readPoint":{},
    "readMember":{},
    "lang":False,
    "addbots":False,
    "dellbots":False,
    "blacklist":{},
    "wblacklist":False,
    "dblacklist":False,
    "Talkblacklist":{},
    "Talkwblacklist":False,
    "Talkdblacklist":False,
    "talkban":True,
    "contact":False,
    "autoRead": False,
    "autoBlock": False,
    "autoJoin":True,
    "autoAdd":False,
    'autoCancel':{"on":True, "members":1},
    "autoReject":False,
    'autoLeave1':False,
    "autoLeave":False,
    "detectMention":False,
    "detectMention2":False,
    "Mentionkick":False,
    "Mentiongift":False,
    "welcomeOn":False,
    "Unsend":False,
    "sticker":False,
    "selfbot":True,
    "mention":"ʜᵃʸᵒᵒᵒ ᴋᵉᵗᵃʰᵘᵃⁿ ɴᵍⁱⁿᵗⁱᵖ... !!!\nsⁱⁿⁱ ᴋᵃᵏ, ɢᵃᵇᵘⁿᵍ ᴄʰᵃᵗ\nʙⁱᵃʳ ɢᵃᵏ ᴋᵉˡⁱʰᵃᵗᵃⁿ ᴊᵒⁿᵉˢ",
    "Respontag":"ɢᴏsᴀʜ ᴛᴀɢ ᴅᴇᴄʜ sᴏᴋ ᴋᴇɴᴀʟ ʟᴏᴄʜ",
    "Respontag2":"ɢᴏsᴀʜ ᴛᴀɢ ɢᴜᴀ ɴᴛᴀʀ ʙɪɴɪᴍᴜ ᴍᴀʀᴀʜ",
    "welcome":"sᵉˡᵃᵐᵃᵗ ᴅᵃᵗᵃⁿᵍ ᴅᵃⁿ sᵉˡᵃᵐᵃᵗ ʙᵉʳᵍᵃᵇᵘⁿᵍ",
    "autoLeave":"ɪɴᴀʟɪʟᴀʜɪ ᴡᴀ'ɪɴᴀʟɪʟᴀʜɪ ʀᴏᴊɪᴜɴ",
    "comment":"┌──────────────────┐\n│     🔳 OPEN ORDER 🔳 \n├──────────────────\n│🎧FITUR LINE & SMULE🎤\n├──────────────────\n┝[]►Coin Line\n┝[]►Coin Gift\n┝[]►Vip Smule Android\n┝[]►Beku Akun Smule\n┝[]►Follower Smule\n┝[]►Songbook Smule\n│☛🏧Via Bank & Pulsa📱\n│♛♛♛♛♛♛♛♛♛♛♛♛♛♛\n├──────────────────\n│⚙️PROTECT & SELFBOT 🔧\n├──────────────────\n┝[]►Selfbot Only\n┝[]►Selfbot Only + Ajs\n┝[]►Selfbot Template\n┝[]►Selfbot Template + Ajs\n┝[]►Bot Protect Rom Smule\n┝[]►Bot Protect Rom Event\n│☛If Order Creator:\n│http://line.me/ti/p/~greetolala990\n│♛♛♛♛♛♛♛♛♛♛♛♛♛♛\n├──────────────────\n│Suport:⭕GʀᴇᴛQᴜᴇᴇɴ Sʜᴏᴘ⭕\n└──────────────────",
    "message1":"ᴛʜᴀɴᴋᴢ ғᴏʀᴅ ᴀᴅᴅ ᴍᴇ\n┌──────────────────┐\n│     🔳 OPEN ORDER 🔳 \n├──────────────────\n│🎧FITUR LINE & SMULE🎤\n├──────────────────\n┝[]►Coin Line\n┝[]►Coin Gift\n┝[]►Vip Smule Android\n┝[]►Beku Akun Smule\n┝[]►Follower Smule\n┝[]►Songbook Smule\n│☛🏧Via Bank & Pulsa📱\n│♛♛♛♛♛♛♛♛♛♛♛♛♛♛\n├──────────────────\n│⚙️PROTECT & SELFBOT 🔧\n├──────────────────\n┝[]►Selfbot Only\n┝[]►Selfbot Only + Ajs\n┝[]►Selfbot Template\n┝[]►Selfbot Template + Ajs\n┝[]►Bot Protect Rom Smule\n┝[]►Bot Protect Rom Event\n│☛If Order Creator:\n│http://line.me/ti/p/~greetolala990\n│♛♛♛♛♛♛♛♛♛♛♛♛♛♛\n├──────────────────\n│Suport:⭕GʀᴇᴛQᴜᴇᴇɴ Sʜᴏᴘ⭕\n└──────────────────",
}
protect = {
    "pqr":[],
    "pinv":[],
    "proall":[],
    "antijs":[],
    "protect":[]
}

read = {
    "readPoint":{},
    "readMember":{},
    "readTime":{},
    "ROM":{},
}

cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}

myProfile = {
	"displayName": "",
	"statusMessage": "",
	"pictureStatus": ""
}
try:
    with open("Log_data.json","r",encoding="utf_8_sig") as f:
        msg_dict = json.loads(f.read())
except:
    print("Couldn't read Log data")
    
clProfile = cl.getProfile()
myProfile["displayName"] = clProfile.displayName
myProfile["statusMessage"] = clProfile.statusMessage
myProfile["pictureStatus"] = clProfile.pictureStatus

contact = cl.getProfile()
backup = cl.getProfile()
backup.displayName = contact.displayName
backup.statusMessage = contact.statusMessage
backup.pictureStatus = contact.pictureStatus


imagesOpen = codecs.open("image.json","r","utf-8")
images = json.load(imagesOpen)
videosOpen = codecs.open("video.json","r","utf-8")
videos = json.load(videosOpen)
stickersOpen = codecs.open("sticker.json","r","utf-8")
stickers = json.load(stickersOpen)
audiosOpen = codecs.open("audio.json","r","utf-8")
audios = json.load(audiosOpen)
mulai = time.time()

msg_dict = {}
msg_dict1 = {}

tz = pytz.timezone("Asia/Jakarta")
timeNow = datetime.now(tz=tz)
           
def cTime_to_datetime(unixtime):
    return datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))

def autolike():
    for zx in range(0,500):
      hasil = cl.activity(limit=500)
      if hasil['result']['posts'][zx]['postInfo']['liked'] == True:
        try:
          cl.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1001)
          cl.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postid'],wait["comment"])
          print ("✪[]► Like Success")
        except:
          pass
      else:
          print ("Already Liked")
    
def dt_to_str(dt):
    return dt.strftime('%H:%M:%S')

#delete log if pass more than 24 hours
def delete_log():
    ndt = datetime.now()
    for data in msg_dict:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > datetime.timedelta(1):
            del msg_dict[msg_id]
        
def delete_log():
    ndt = datetime.now()
    for data in msg_dict:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > timedelta(1):
            if "path" in msg_dict[data]:
                cl.deleteFile(msg_dict[data]["path"])
            del msg_dict[data]

def logError(text):
    cl.log("[ ERROR ] {}".format(str(text)))
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    time = "{}, {} - {} - {} | {}".format(str(hasil), str(inihari.strftime('%d')), str(bln), str(inihari.strftime('%Y')), str(inihari.strftime('%H:%M:%S')))
    with open("logError.txt","a") as error:
        error.write("\n[ {} ] {}".format(str(time), text))

def download_page(url):
    version = (3,0)
    cur_version = sys.version_info
    if cur_version >= version:     
        import urllib,request
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
            req = urllib,request.Request(url, headers = headers)
            resp = urllib,request.urlopen(req)
            respData = str(resp.read())
            return respData
        except Exception as e:
            print(str(e))
    else:                        
        import urllib2
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
            req = urllib2.Request(url, headers = headers)
            response = urllib2.urlopen(req)
            page = response.read()
            return page
        except:
            return"Page Not found"

def _images_get_all_items(page):
    items = []
    while True:
        item, end_content = _images_get_next_item(page)
        if item == "no_links":
            break
        else:
            items.append(item)      
            time.sleep(0.1)        
            page = page[end_content:]
    return items

def downloadImageWithURL (mid):
    contact = cl.getContact(mid)
    if contact.videoProfile == None:
        cl.cloneContactProfile(mid)
    else:
        profile = cl.getProfile()
        profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
        cl.updateProfile(profile)
        pict = cl.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus, saveAs="tmp/pict.bin")
        vids = cl.downloadFileURL( 'http://dl.profile.line-cdn.net/' + contact.pictureStatus + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = cl.getProfileDetail(mid)['result']['objectId']
    cl.updateProfileCoverById(coverId)
    
def restartBot():
    python = sys.executable
    os.execl(python, python, *sys.argv)

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)
    
def sendImage(to, path, name="image"):
    try:
        if settings["server"] == "VPS":
            cl.sendImageWithURL(to, str(path))
    except Exception as error:
        logError(error)

def changeProfileVideo(to):
    if settings['changevp']['picture'] == True:
        return cl.sendMessage(to, "Foto tidak ditemukan")
    elif settings['changevp']['video'] == True:
        return cl.sendMessage(to, "Video tidak ditemukan")
    else:
        path = settings['changevp']['video']
        files = {'file': open(path, 'rb')}
        obs_params = cl.genOBSParams({'oid': cl.getProfile().mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = cl.server.postContent('{}/talk/vp/upload.nhn'.format(str(cl.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return cl.sendMessage(to, "Gagal update profile")
        path_p = settings['changevp']['picture']
        settings['changevp']['status'] = True
        cl.updateProfilePicture(path_p, 'vp')
                     
def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = cl.genOBSParams({'oid': mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4', 'name': 'GEGE.mp4'})
        data = {'params': obs_params}
        r_vp = cl.server.postContent('{}/talk/vp/upload.nhn'.format(str(cl.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        cl.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile %s"%str(e))

def cloneProfile(mid):
    contact = cl.getContact(mid)
    if contact.videoProfile == None:
        cl.cloneContactProfile(mid)
    else:
        profile = cl.getProfile()
        profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
        cl.updateProfile(profile)
        pict = cl.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus, saveAs="tmp/pict.bin")
        vids = cl.downloadFileURL( 'http://dl.profile.line-cdn.net/' + contact.pictureStatus + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = cl.getProfileDetail(mid)['result']['objectId']
    cl.updateProfileCoverById(coverId)

def restoreProfile():
    profile = cl.getProfile()
    profile.displayName = settings['myProfile']['displayName']
    profile.statusMessage = settings['myProfile']['statusMessage']
    if settings['myProfile']['videoProfile'] == None:
        profile.pictureStatus = settings['myProfile']['pictureStatus']
        cl.updateProfileAttribute(8, profile.pictureStatus)
        cl.updateProfile(profile)
    else:
        cl.updateProfile(profile)
        pict = cl.downloadFileURL('http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'], saveAs="tmp/pict.bin")
        vids = cl.downloadFileURL( 'http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'] + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = settings['myProfile']['coverId']
    cl.updateProfileCoverById(coverId)

def mentionMembers(to, mid):
    try:
        arrData = ""
        ginfo = cl.getGroup(to)
        textx = "☸ Total Mention「{}」☸\n\n•✍͡➴͜❂".format(str(len(mid)))
        arr = []
        no = 1
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "•✍͡➴͜❂".format(str(no))
            else:
                textx += "╚══════════════════\n╔══════════════════\n  「 ᴛᴏᴛᴀʟ ᴍᴇᴍʙᴇʀ : {} 」\n╚══════════════════".format(str(len(mid)))
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def siderMembers(to, mid):
    try:
        arrData = ""
        textx = "☸ᴛᴇʀᴄʏᴅᴜᴋ「{}」☸\n✍͡➴͜❂ʜᴀɪ..".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["mention"]
            if no < len(mid):
                no += 1
                textx += "%i. " % (num)
                num=(num)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        #cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        data = {
            "type": "text",
            "text": "✍͡➴͜❂ʜᴀɪ..「{}」\n".format(cl.getContact(op.param2).displayName) + wait["mention"],
            "sentBy": {
                "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
            }
        }
        cl.postTemplate(op.param1, data)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def welcomeMembers(to, mid):
    try:
        arrData = ""
        textx = "☸ᴍᴇᴍʙᴇʀ ᴍᴀsᴜᴋ「{}」☸\n✍͡➴͜❂".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = cl.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["welcome"]+"\nɴᴀᴍᴀ ɢʀᴏᴜᴘ: "+str(ginfo.name)
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        #cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        data = {
            "type": "text",
            "text": "✍͡➴͜❂ʜᴀɪ..「{}」\n".format(cl.getContact(op.param2).displayName) + wait["welcome"],
            "sentBy": {
                "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
            }
        }
        cl.postTemplate(to, data)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))
def leaveMembers(to, mid):
    try:
        arrData = ""
        textx = "☸ᴍᴇᴍʙᴇʀ ʟᴇᴀᴠᴇ「{}」☸\n•✍͡➴͜❂ʙʏᴇᴇ..".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = cl.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["autoLeave"]+"\nɴᴀᴍᴀ ɢʀᴏᴜᴘ : "+str(ginfo.name)
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
       # cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        data = {
            "type": "text",
            "text": "✍͡➴͜❂ʙʏᴇᴇ.「{}」\n".format(cl.getContact(op.param2).displayName) + wait["autoLeave"],
            "sentBy": {
                "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
            }
        }
        cl.postTemplate(to, data)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendMention(to, mid, firstmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x \n"
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        today = datetime.today()
        future = datetime(2018,3,1)
        hari = (str(future - today))
        comma = hari.find(",")
        hari = hari[:comma]
        teman = cl.getAllContactIds()
        gid = cl.getGroupIdsJoined()
        tz = pytz.timezone("Asia/Jakarta")
        timeNow = datetime.now(tz=tz)
        eltime = time.time() - mulai
        bot = runtime(eltime)
        text += mention+"jam : "+datetime.strftime(timeNow,'%H:%M:%S')+" wib\nNama Group : "+str(len(gid))+"\nTeman : "+str(len(teman))+"\nExpired : In "+hari+"\n Version :「Gaje Bots」  \nTanggal : "+datetime.strftime(timeNow,'%Y-%m-%d')+"\nRuntime : \n • "+bot
        cl.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendMention1(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        cl.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)                     
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendTemplates(to, data):
    data = data
    url = "https://api.line.me/message/v3/share"
    headers = {}
    headers['User-Agent'] = 'Mozilla/5.0 (Linux; Android 8.1.0; Redmi Note 5 Build/OPM1.171019.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/67.0.3396.87 Mobile Safari/537.36 Line/8.1.1'  
    headers['Content-Type'] = 'application/json'  
    headers['Authorization'] = 'Bearer eyJhbGciOiJIUzI1NiJ9.5uMcEEHahauPb5_MKAArvGzEP8dFOeVQeaMEUSjtlvMV9uuGpj827IGArKqVJhiGJy4vs8lkkseiNd-3lqST14THW-SlwGkIRZOrruV4genyXbiEEqZHfoztZbi5kTp9NFf2cxSxPt8YBUW1udeqKu2uRCApqJKzQFfYu3cveyk.GoRKUnfzfj7P2uAX9vYQf9WzVZi8MFcmJk8uFrLtTqU'
    sendPost = requests.post(url, data=json.dumps(data), headers=headers)
    print(sendPost)
    return sendPost

   
def command(text):
    pesan = text.lower()
    if pesan.startswith(Setmain['keyCommand']):
        cmd = pesan.replace(Setmain['keyCommand'],"")
    else:
        cmd = "command"
    return cmd

def help():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage = "╭「⏺️ᴄᴏᴍᴀɴᴅ ʙᴏᴛ⏺️」\n"+\
                  "│⏺️" + key + "ʜᴇʟᴘ ᴄʀᴇᴀᴛᴏʀ\n" + \
                  "│⏺️" + key + "ʜᴇʟᴘ sᴇᴛᴛɪɴɢ\n" + \
                  "│⏺️" + key + "ʜᴇʟᴘ ᴍᴇᴅɪᴀ\n" + \
                  "│⏺️" + key + "ʜᴇʟᴘ ɢʀᴏᴜᴘ\n" + \
                  "│⏺️" + key + "ʜᴇʟᴘ ᴀᴅᴍɪɴ\n" + \
                  "│⏺️" + key + "ʜᴇʟᴘ ɢʜᴏsᴛ\n" + \
                  "╰「⏺️sᴇʟғ ᴘʏᴛʜᴏɴ³⏺️」"
    return helpMessage
def helpcreator():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage1 = "╭「⏺️ᴄᴏᴍᴀɴᴅ ʙᴏᴛ⏺️」\n"+\
                  "│⏺️" + key + "ᴍᴇ\n" + \
                  "│⏺️" + key + "sᴛᴀᴛᴜs\n" + \
                  "│⏺️" + key + "sᴇᴛᴛɪɴɢ\n" + \
                  "│⏺️" + key + "ʀᴜɴᴛɪᴍᴇ\n" + \
                  "│⏺️" + key + "ᴄʀᴇᴀᴛᴏʀ\n" + \
                  "│⏺️" + key + "sᴘᴇᴇᴅ-sᴘ\n" + \
                  "│⏺️" + key + "sᴀɴᴛᴇᴛ ᴍᴀɴᴛᴀɴ\n" + \
                  "│⏺️" + key + "ʙʏᴇᴍᴇ\n" + \
                  "│⏺️" + key + "ʀᴇᴊᴇᴄᴛ\n" + \
                  "│⏺️" + key + "ʟᴇᴀᴠᴇᴀʟʟ\n" + \
                  "│⏺️" + key + "ʟɪsᴛғʀɪᴇɴᴅ\n" + \
                  "│⏺️" + key + "ғʀɪᴇɴᴅʟɪsᴛ\n" + \
                  "│⏺️" + key + "ɢʀᴏᴜᴘʟɪsᴛ\n" + \
                  "│⏺️" + key + "ᴏᴘᴇɴ ǫʀ\n" + \
                  "│⏺️" + key + "ᴄʟᴏsᴇ ǫʀ\n" + \
                  "│⏺️" + key + "ᴛᴀɢᴀʟʟ\n" + \
                  "│⏺️" + key + ".ɪɴᴠɪᴛᴇ @\n" + \
                  "│⏺️" + key + ".ᴊᴏɪɴ「ɢʀᴜᴘ-ɴᴏ」\n" + \
                  "│⏺️" + key + "ʙʟᴏᴄᴋ「@」\n" + \
                  "│⏺️" + key + "ᴀᴅᴅᴍᴇ「@」\n" + \
                  "│⏺️" + key + "ᴍʏʙᴏᴛ\n" + \
                  "│⏺️" + key + "ʟɪsᴛᴘᴇɴᴅɪɴɢ\n" + \
                  "│⏺️" + key + "ʙʟᴏᴄᴋᴄᴏɴᴛᴀᴄᴛ\n" + \
                  "│⏺️" + key + "ʟᴋsᴛʙʟᴏᴄᴋ\n" + \
                  "│⏺️" + key + "ʟɪsᴛᴍɪᴅ\n" + \
                  "│⏺️" + key + "ᴀᴅᴅᴀsɪs\n" + \
                  "│⏺️" + key + "ʙʀᴏᴀᴅᴄᴀsᴛ:「ᴛᴇxᴛ」\n" + \
                  "╰「⏺️sᴇʟғ ᴘʏᴛʜᴏɴ³⏺️」"
    return helpMessage1

def helpadmin():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage5 = "╭「⏺️ᴄᴏᴍᴀɴᴅ ʙᴏᴛ⏺️」\n"+\
                  "│⏺️"  + key + "ʙᴏᴛᴀᴅᴅ「@」\n" + \
                  "│⏺️"  + key + "ʙᴏᴛᴅᴇʟʟ「@」\n" + \
                  "│⏺️"  + key + "sᴛᴀғᴀᴅᴅ「@」\n" + \
                  "│⏺️"  + key + "sᴛᴀғᴅᴇʟʟ「@」\n" + \
                  "│⏺️"  + key + "ᴀᴅᴍɪɴᴀᴅᴅ「@」\n" + \
                  "│⏺️"  + key + "ᴀᴅᴍɪɴᴅᴇʟʟ「@」\n" + \
                  "│⏺️"  + key + "ʀᴇʙᴏᴏᴛ\n" + \
                  "│⏺️"  + key + "ʙᴀɴ「@」\n" + \
                  "│⏺️"  + key + "ʙʟᴄ\n" + \
                  "│⏺️"  + key + "ʙᴀɴ:ᴏɴ\n" + \
                  "│⏺️"  + key + "ᴜɴʙᴀɴ:oɴ\n" + \
                  "│⏺️"  + key + "ᴜɴʙᴀɴ「@」\n" + \
                  "│⏺️"  + key + "ʙᴀɴʟɪsᴛ\n" + \
                  "│⏺️"  + key + "ᴄᴇʙᴀɴ\n" + \
                  "│⏺️"  + key + "ʀᴇғʀᴇsʜ\n" + \
                  "╰「⏺️sᴇʟғ ᴘʏᴛʜᴏɴ³⏺️」"
    return helpMessage5
  
def helpgroup():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage4 = "╭「⏺️sᴇʟғ ᴘʏᴛʜᴏɴ³⏺️」\n"+\
                  "│⏺️" + key + "ɢᴍɪᴅ @\n" + \
                  "│⏺️" + key + "ɢᴇᴛ ɪᴅ @\n" + \
                  "│⏺️" + key + "ɢᴇᴛᴍɪᴅ @\n" + \
                  "│⏺️" + key + "ɢᴇᴛʙɪᴏ @\n" + \
                  "│⏺️" + key + "ɢᴇᴛɪɴғᴏ @\n" + \
                  "│⏺️" + key + "ɢᴇᴛᴘʀᴏғɪʟᴇ @\n" + \
                  "│⏺️" + key + "ɢᴇᴛᴘɪᴄᴛᴜʀᴇ @\n" + \
                  "│⏺️" + key + "ɪɴғᴏ @\n" + \
                  "│⏺️" + key + "ᴋᴇᴘᴏ @\n" + \
                  "│⏺️" + key + "ᴘᴘᴠɪᴅᴇᴏ @\n" + \
                  "│⏺️" + key + "ᴋᴏɴᴛᴀᴋ @\n" + \
                  "│⏺️" + key + "ᴄᴏɴᴛᴀᴄᴛ:「ᴍɪᴅ」\n" + \
                  "│⏺️" + key + "ɢɴᴀᴍᴇ「ᴛᴇxᴛ」\n" + \
                  "│⏺️" + key + "ᴍʏᴍɪᴅ\n" + \
                  "│⏺️" + key + "ᴍʏʙɪᴏ\n" + \
                  "│⏺️" + key + "ᴍʏғᴏᴛᴏ\n" + \
                  "│⏺️" + key + "ᴍʏɴᴀᴍᴇ\n" + \
                  "│⏺️" + key + "ᴍʏᴘʀᴏғɪʟᴇ\n" + \
                  "│⏺️" + key + "ᴍʏᴘɪᴄᴛᴜʀᴇ\n" + \
                  "│⏺️" + key + "ᴍʏᴄᴏᴠᴇʀ\n" + \
                  "│⏺️" + key + "ᴍʏᴠɪᴅᴇᴏ\n" + \
                  "│⏺️" + key + "ᴋᴀʟᴇɴᴅᴇʀ\n" + \
                  "│⏺️" + key + "ᴍᴇᴍᴘɪᴄᴛ\n" + \
                  "│⏺️" + key + "ᴄʜᴀɴɢᴇᴠᴘ\n" + \
                  "│⏺️" + key + "ᴜᴘᴅᴀᴛᴇɢʀᴜᴘ\n" + \
                  "│⏺️" + key + "ɢʀᴜᴘᴘɪᴄᴛ\n" + \
                  "│⏺️" + key + "ɪɴғᴏɢʀᴏᴜᴘ「ɴᴏ」\n" + \
                  "│⏺️" + key + "ɪɴғᴏᴍᴇᴍ「ɴᴏ」\n" + \
                  "╰「⏺️sᴇʟғ ᴘʏᴛʜᴏɴ³⏺️」"
    return helpMessage4
def helpsetting():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage2 = "╭「⏺️sᴇʟғ ᴘʏᴛʜᴏɴ³⏺️」\n"+\
                  "│⏺️" + key + "ᴄᴇᴋ sɪᴅᴇʀ\n" + \
                  "│⏺️" + key + "ᴄᴇᴋ ʟᴇᴀᴠᴇ \n" + \
                  "│⏺️" + key + "ᴄᴇᴋ sᴘᴀᴍ \n" + \
                  "│⏺️" + key + "ᴄᴇᴋ ᴘᴇsᴀɴ \n" + \
                  "│⏺️" + key + "ᴄᴇᴋ ʀᴇsᴘᴏɴ \n" + \
                  "│⏺️" + key + "ᴄᴇᴋ ʀᴇsᴘᴏɴ² \n" + \
                  "│⏺️" + key + "sᴇᴛ sɪᴅᴇʀ:「ᴛᴇxᴛ」\n" + \
                  "│⏺️" + key + "sᴇᴛ sᴘᴀᴍ:「ᴛᴇxᴛ」\n" + \
                  "│⏺️" + key + "sᴇᴛ ᴘᴇsᴀɴ:「ᴛᴇxᴛ」\n" + \
                  "│⏺️" + key + "sᴇᴛ ʀᴇsᴘᴏɴ:「ᴛᴇxᴛ」\n" + \
                  "│⏺️" + key + "sᴇᴛ ʀᴇsᴘᴏɴ²:「ᴛᴇxᴛ」\n" + \
                  "│⏺️" + key + "sᴇᴛ ᴡᴇʟᴄᴏᴍᴇ:「ᴛᴇxᴛ」\n" + \
                  "│⏺️" + key + "sᴇᴛ ʟᴇᴀᴠᴇ:「ᴛᴇxᴛ」\n" + \
                  "│⏺️" + key + "ɢɪғᴛ:「ᴍɪᴅ」「ᴊᴜᴍʟᴀʜ」\n" + \
                  "│⏺️" + key + "sᴘᴀᴍ:「ᴍɪᴅ」「ᴊᴜᴍʟᴀʜ」\n" + \
                  "│⏺️" + key + "ʟɪᴋᴇ「ᴏɴ/ᴏғғ」\n" + \
                  "│⏺️" + key + "ᴘᴏsᴛ「oɴ/oғғ」\n" + \
                  "│⏺️" + key + "sᴛɪᴄᴋᴇʀ「oɴ/oғғ」\n" + \
                  "│⏺️" + key + "ɪɴᴠɪᴛᴇ「oɴ/ᴏғғ」\n" + \
                  "│⏺️" + key + "ᴜɴsᴇɴᴅ「oɴ/oғғ」\n" + \
                  "│⏺️" + key + "ʀᴇsᴘᴏɴ「oɴ/oғғ」\n" + \
                  "│⏺️" + key + "ʀᴇsᴘᴏɴ²「oɴ/oғғ」\n" + \
                  "│⏺️" + key + "ᴀᴜᴛᴏᴀᴅᴅ「oɴ/oғғ」\n" + \
                  "│⏺️" + key + "ᴡᴇʟᴄᴏᴍᴇ「oɴ/oғғ」\n" + \
                  "│⏺️" + key + "ᴄᴏɴᴛᴀᴄᴛ「oɴ/oғғ」\n" + \
                  "│⏺️" + key + "ᴀᴜᴛᴏᴊᴏɪɴ「oɴ/oғғ」\n" + \
                  "│⏺️" + key + "ᴀᴜᴛᴏʀᴇᴊᴇᴄᴛ「oɴ/oғғ」\n" + \
                  "│⏺️" + key + "ᴀᴜᴛᴏʟᴇᴀᴠᴇ「oɴ/oғғ」\n" + \
                  "│⏺️" + key + "ᴀᴜᴛᴏʙʟᴏᴄᴋ「oɴ/oғғ」\n" + \
                  "│⏺️" + key + "ᴊᴏɪɴᴛɪᴄᴋᴇᴛ「oɴ/oғғ」\n" + \
				  "╰「⏺️sᴇʟғ ᴘʏᴛʜᴏɴ³⏺️」"
    return helpMessage2
def media():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage3 = "╔═══════════\n" + \
"┣[🇧🇩]► " + key + "Addsticker\n" + \
"┣[🇧🇩]► " + key + "Addmp3\n" + \
"┣[🇧🇩]► " + key + "Addaudio\n" + \
"┣[🇧🇩]► " + key + "Addimg\n" + \
"┣[🇧🇩]► " + key + "Dellsticker\n" + \
"┣[🇧🇩]► " + key + "Dellaudio\n" + \
"┣[🇧🇩]► " + key + "Dellmp3\n" + \
"┣[🇧🇩]► " + key + "Dellvideo\n" + \
"┣[🇧🇩]► " + key + "Dellimg\n" + \
"┣[🇧🇩]► " + key + "Liststicker\n" + \
"┣[🇧🇩]► " + key + "Listimage\n" + \
"┣[🇧🇩]► " + key + "Listvideo\n" + \
"┣[🇧🇩]► " + key + "Listaudio\n" + \
"┣[🇧🇩]► " + key + "Listmp3\n" + \
"┣[🇧🇩]► " + key + "Lihat「No」\n" + \
"┣[🇧🇩]► " + key + "Cctv metro\n" + \
"┣[🇧🇩]► " + key + "Smule「id」\n" + \
"┣[🇧🇩]► " + key + "Imgfood「text」\n" + \
"┣[🇧🇩]► " + key + "Joox「text」\n" + \
"┣[🇧🇩]► " + key + "mp4「text」\n" + \
"┣[🇧🇩]► " + key + "mp3「text」\n" + \
"┣[🇧🇩]► " + key + "Yutube「text」\n" + \
"┣[🇧🇩]► " + key + "Youtube「text」\n" + \
"╚═══════════"
    return helpMessage3

def helpghost():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage6 = "╭「⏺️ᴄᴏᴍᴀɴᴅ ʙᴏᴛ⏺️」\n"+\
                  "│⏺️"  + key + "sᴛᴀʏ\n" + \
                  "│⏺️"  + key + "ᴊs ɪɴ-ᴏᴜᴛ\n" + \
                  "│⏺️"  + key + "ᴀᴊsғᴏᴛᴏ\n" + \
                  "│⏺️"  + key + "ᴊs ᴀʙsᴇɴ\n" + \
                  "│⏺️"  + key + "ᴊs ᴄᴀɴᴄᴇʟ\n" + \
                  "│⏺️"  + key + "ᴊs ᴋɪᴄᴋᴀʟʟ\n" + \
                  "│⏺️"  + key + "ᴘᴀs ʙᴀɴᴅ\n" + \
                  "│⏺️"  + key + "ᴊsɴᴀᴍᴇ [ᴛᴇxᴛ]\n" + \
                  "│⏺️"  + key + "ᴄᴇᴋʙᴏᴛ\n" + \
                  "│⏺️"  + key + "ᴋɪᴄᴋ「@」\n" + \
                  "│⏺️"  + key + "ᴄʀᴏᴛ-ᴄʀɪᴛ\n" + \
                  "╰「⏺️sᴇʟғ ᴘʏᴛʜᴏɴ³⏺️」"
    return helpMessage6

def bot(op):
    global time
    global ast
    global groupParam
    try:
        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoBlock"] == True:
                cl.blockContact(op.param1)
                cl.sendMessage(op.param1,"ᴛʜᴀɴᴋᴢ ғᴏʀᴅ ᴀᴅᴅ ᴍᴇ\n┌──────────────────┐\n│     🔳 OPEN ORDER 🔳 \n├──────────────────\n│🎧FITUR LINE & SMULE🎤\n├──────────────────\n┝[]►Coin Line\n┝[]►Coin Gift\n┝[]►Vip Smule Android\n┝[]►Beku Akun Smule\n┝[]►Follower Smule\n┝[]►Songbook Smule\n│☛🏧Via Bank & Pulsa📱\n│♛♛♛♛♛♛♛♛♛♛♛♛♛♛\n├──────────────────\n│⚙️PROTECT & SELFBOT 🔧\n├──────────────────\n┝[]►Selfbot Only\n┝[]►Selfbot Only + Ajs\n┝[]►Selfbot Template\n┝[]►Selfbot Template + Ajs\n┝[]►Bot Protect Rom Smule\n┝[]►Bot Protect Rom Event\n│☛If Order Creator:\n│http://line.me/ti/p/~slanker123456\n│♛♛♛♛♛♛♛♛♛♛♛♛♛♛\n├──────────────────\n│Suport:⭕GʀᴇᴛQᴜᴇᴇɴ Sʜᴏᴘ⭕\n└──────────────────")

        if op.type == 13:
            if mid in op.param3:
                if wait["autoLeave"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
                        cl.sendMessage(op.param1,"aĸυ eмooн coĸ \n┣🚫► Group " +str(ginfo.name))
                        cl.leaveGroup(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
                        cl.sendMessage(op.param1,"Maksih sudah di invit" + str(ginfo.name))

        if op.type == 13:
            if mid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
                        cl.sendMessage(op.param1,"ᴛʜᴀɴᴋs ғᴏʀ ɪɴᴠɪᴛᴇ")
                    else:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
                        cl.sendMessage(op.param1,"ᴛʜᴀɴᴋs ғᴏʀ ɪɴᴠɪᴛᴇ")

        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoAdd"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    if (wait["message1"] in [" "," ","\n",None]):
                        pass
                    else:
                        cl.sendMessage(op.param1, wait["message1"])

        if op.type == 13:
            if mid in op.param3:
               if wait["autoReject"] == True:
                   if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                       cl.rejectGroupInvitation(op.param1)
                       time.sleep(1)

        if op.type == 19:
            if mid in op.param3:
            	if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        k1.acceptGroupInvitation(op.param1)
                        k1.inviteIntoGroup(op.param1,[mid])
                        k1.kickoutFromGroup(op.param1,[op.param2])
                        cl.acceptGroupInvitation(op.param1)
                        k1.leaveGroup(op.param1)
                        cl.inviteIntoGroup(op.param1,[Amid])
                        wait["blacklist"][op.param2] = True
                    except:
                        pass
        if op.type == 19:
            if mid in op.param3:
            	if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        k2.acceptGroupInvitation(op.param1)
                        k2.inviteIntoGroup(op.param1,[mid])
                        k2.kickoutFromGroup(op.param1,[op.param2])
                        cl.acceptGroupInvitation(op.param1)
                        k2.leaveGroup(op.param1)
                        cl.inviteIntoGroup(op.param1,[Bmid])
                        wait["blacklist"][op.param2] = True
                    except:
                        pass
        if op.type == 19:
            if mid in op.param3:
            	if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        sw.acceptGroupInvitation(op.param1)
                        sw.inviteIntoGroup(op.param1,[mid])
                        sw.kickoutFromGroup(op.param1,[op.param2])
                        cl.acceptGroupInvitation(op.param1)
                        sw.leaveGroup(op.param1)
                        cl.inviteIntoGroup(op.param1,[Zmid])
                        wait["blacklist"][op.param2] = True
                    except:
                        pass
        if op.type == 19:
            if Amid in op.param3:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        cl.inviteIntoGroup(op.param1,[Amid])
                    except:
                        pass
        if op.type == 19:
            if Bmid in op.param3:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        cl.inviteIntoGroup(op.param1,[Bmid])
                    except:
                        pass
        if op.type == 19:
            if Zmid in op.param3:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        cl.inviteIntoGroup(op.param1,[Zmid])
                    except:
                        pass
        if op.type == 32:
            if op.param3 in Amid:
              if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                  wait["blacklist"][op.param2] = True
                  try:
                      if op.param3 not in wait["blacklist"]:
                          cl.kickoutFromGroup(op.param1,[op.param2])
                          cl.inviteIntoGroup(op.param1,[Amid])
                          k1.kickoutFromGroup(op.param1,[op.param2])
                          sendTextTemplate1(op.param1,"Anjirrr...di cancel")
                  except:
                      pass
        if op.type == 32:
            if op.param3 in Bmid:
              if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                  wait["blacklist"][op.param2] = True
                  try:
                      if op.param3 not in wait["blacklist"]:
                          cl.kickoutFromGroup(op.param1,[op.param2])
                          cl.inviteIntoGroup(op.param1,[Bmid])
                          k2.kickoutFromGroup(op.param1,[op.param2])
                          sendTextTemplate1(op.param1,"Anjirrr...di cancel")
                  except:
                      pass
        if op.type == 32:
            if op.param3 in Zmid:
              if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                  wait["blacklist"][op.param2] = True
                  try:
                      if op.param3 not in wait["blacklist"]:
                          cl.kickoutFromGroup(op.param1,[op.param2])
                          cl.inviteIntoGroup(op.param1,[Zmid])
                          sw.kickoutFromGroup(op.param1,[op.param2])
                          sendTextTemplate1(op.param1,"Anjirrr...di cancel")
                  except:
                      pass
        if op.type == 32:
            if wait["tumbal"] == True:
              if op.param3 in Tumbal:
                if op.param2 not in Bots and op.param2 not in creator and op.param2 not in admin:
                    wait["blacklist"][op.param2] = True
                    try:
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        cl.inviteIntoGroup(op.param1,Tumbal)
                    except:
                    	pass
                return
        if op.type == 65:
            if wait["Unsend"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict:
                        if msg_dict[msg_id]["from"]:
                           if msg_dict[msg_id]["text"] == 'Gambarnya dibawah':
                                ginfo = cl.getGroup(at)
                                ryan = cl.getContact(msg_dict[msg_id]["from"])
                                zx = ""
                                zxc = ""
                                zx2 = []
                                xpesan =  "╔══「 Gambar Dihapus 」\n┣[]► Pengirim : "
                                ret_ = "┣[]► Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n┣[]► Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                ret_ += "\n╚══「 Unsend Finish 」"
                                ry = str(ryan.displayName)
                                pesan = ''
                                pesan2 = pesan+"@x \n"
                                xlen = str(len(zxc)+len(xpesan))
                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                zx2.append(zx)
                                zxc += pesan2
                                text = xpesan + zxc + ret_ + ""
                                cl.sendMessage(at, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                cl.sendImage(at, msg_dict[msg_id]["data"])
                           else:
                                ginfo = cl.getGroup(at)
                                ryan = cl.getContact(msg_dict[msg_id]["from"])
                                ret_ =  "╔══「 Pesan Dihapus 」\n"
                                ret_ += "┣[]► Pengirim : {}".format(str(ryan.displayName))
                                ret_ += "\n┣[]► Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n┣[]► Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                ret_ += "\n┣[]► Pesannya : {}".format(str(msg_dict[msg_id]["text"]))
                                ret_ += "\n╚══「 Unsend Finish 」"
                                cl.sendMessage(at, str(ret_))
                        del msg_dict[msg_id]
                except Exception as e:
                    print(e)

        if op.type == 65:
            if wait["Unsend"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict1:
                        if msg_dict1[msg_id]["from"]:
                                ginfo = cl.getGroup(at)
                                ryan = cl.getContact(msg_dict1[msg_id]["from"])
                                ret_ =  "╔══「✯sᴛɪᴄᴋᴇʀ ɪɴғᴏ✯」\n"
                                ret_ += "┣[]► ᴾᵉˡᵃᵏᵘ : {}".format(str(ryan.displayName))
                                ret_ += "\n┣[]► ᴳʳᵒᵘᵖ: {}".format(str(ginfo.name))
                                ret_ += "\n┣[]► ᵀⁱᵐᵉ: {}".format(dt_to_str(cTime_to_datetime(msg_dict1[msg_id]["createdTime"])))
                                ret_ += "\n╚══「✯ᴜɴsᴇɴᴅ ғɪɴɪsʜ✯」"
                                ret_ += "{}".format(str(msg_dict1[msg_id]["text"]))
                                cl.sendMessage(at, str(ret_))
                                cl.sendImage(at, msg_dict1[msg_id]["data"])
                        del msg_dict1[msg_id]
                except Exception as e:
                    print(e)
        if op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                if msg.toType == 0:
                    if sender != cl.profile.mid:
                        to = sender
                    else:
                        to = receiver
                elif msg.toType == 1:
                    to = receiver
                elif msg.toType == 2:
                    to = receiver
                if msg.contentType == 0:
                    msg_dict[msg.id] = {"text": msg.text, "from": msg._from, "createdTime": msg.createdTime, "contentType": msg.contentType, "contentMetadata": msg.contentMetadata}
                if msg.contentType == 1:
                    path = cl.downloadObjectMsg(msg_id)
                    msg_dict[msg.id] = {"text":'Gambarnya dibawah',"data":path,"from":msg._from,"createdTime":msg.createdTime}
                if msg.contentType == 7:
                   stk_id = msg.contentMetadata["STKID"]
                   stk_ver = msg.contentMetadata["STKVER"]
                   pkg_id = msg.contentMetadata["STKPKGID"]
                   ret_ = "\n╔══「✯sᴛɪᴄᴋᴇʀ ɪɴғᴏ✯]"
                   ret_ += "\n┣[]►sᴛɪᴄᴋᴇʀ ɪᴅ: {}".format(stk_id)
                   ret_ += "\n┣[]►sᴛɪᴄᴋᴇʀ ᴠᴇʀsɪᴏɴ: {}".format(stk_ver)
                   ret_ += "\n┣[]►sᴛɪᴄᴋᴇʀ ᴘᴀᴄᴋᴀɢᴇ: {}".format(pkg_id)
                   ret_ += "\n┣[]►ᴜʀʟ: ʟɪɴᴇ://shop/detail/{}".format(pkg_id)
                   ret_ += "\n╚══「✯ᴜɴsᴇɴᴅ ғɪɴɪsʜ✯」"
                   query = int(stk_id)
                   if type(query) == int:
                            data = 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(query)+'/ANDROID/sticker.png'
                            path = cl.downloadFileURL(data)
                            msg_dict1[msg.id] = {"text":str(ret_),"data":path,"from":msg._from,"createdTime":msg.createdTime}
#____________________________________________________________________
        if op.type == 17:
            if op.param1 in welcome:
                if op.param2 in Bots:
                    pass
                ginfo = cl.getGroup(op.param1)
                contact = cl.getContact(op.param2)
                image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                welcomeMembers(op.param1, [op.param2])
                cl.sendImageWithURL(op.param1, image)
                cl.sendMessage(op.param1, None, contentMetadata={"STKID":"33227471","STKPKGID":"3144860","STKVER":"1"}, contentType=7)
        if op.type == 15:
            if op.param1 in welcome:
                if op.param2 in Bots:
                    pass
                ginfo = cl.getGroup(op.param1)
                contact = cl.getContact(op.param2)
                image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
               # contact = cl.getContact(op.param2).picturePath
          #      image = 'http://dl.profile.line.naver.jp'+contact
                leaveMembers(op.param1, [op.param2])
                cl.sendImageWithURL(op.param1, image)
                cl.sendMessage(op.param1, None, contentMetadata={"STKID":"15878345","STKPKGID":"1412505","STKVER":"1"}, contentType=7)

        if op.type == 55:
            if cctv['cyduk'][op.param1]==True:
                if op.param1 in cctv['point']:
                    Name = cl.getContact(op.param2).displayName
                    if Name in cctv['sidermem'][op.param1]:
                        pass
                    else:
                        cctv['sidermem'][op.param1] += "\n~ " + Name
                        siderMembers(op.param1, [op.param2])
                        contact = cl.getContact(op.param2)
                     #   image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                      #  cl.sendImageWithURL(op.param1, image)
                        cl.sendMessage(op.param1, None, contentMetadata={"STKID":"16128766","STKPKGID":"1420786","STKVER":"1"}, contentType=7)
#========={{{{{MENTION}}}}}===========
        if op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if settings ["Aip"] == True:
                if msg.text in ["@otong","!curut","Cleanse","!cleanse",".cleanse","zona","!kickall",".kickall","mayhem","Ratakan","bubarkan","Nuke","nuke",".nuke","Bypass","bypass",".bypass","#bypass","#jancok","hancurkan","!malam","winebot",".malam","bubar",".bubar","malam","86","87"]:
                    cl.kickoutFromGroup(receiver,[sender])
            if wait["selfbot"] == True:
               if msg._from not in Bots:
                 if wait["talkban"] == True:
                   if msg._from in wait["Talkblacklist"]:
                      try:
                          cl.kickoutFromGroup(msg.to, [msg._from])
                      except:
                          try:
                              cl.kickoutFromGroup(msg.to, [msg._from])
                          except:
                              try:
                                  cl.kickoutFromGroup(msg.to, [msg._from])
                              except:
                                  try:
                                  	cl.kickoutFromGroup(msg.to, [msg._from])
                                  except:
                                      pass
               if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["detectMention"] == True:
                   contact = cl.getContact(msg._from)
                   name = re.findall(r'@(\w+)', msg.text)
                   image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention["M"] in mid:
                          # cl.sendMessage(msg.to, wait["Respontag"])
                           data = {
                               "type": "text",
                               "text": wait["Respontag"],
                               "sentBy": {
                                   "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                   "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                   "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                               }
                           }
                           cl.postTemplate(to, data)
                        #   cl.sendImageWithURL(msg.to, image)
                           cl.sendMessage(msg.to, None, contentMetadata={"STKID":"94734116","STKPKGID":"4981191","STKVER":"1"}, contentType=7)
                           break
               if 'MENTION' in msg.contentMetadata.keys() != None:
                if msg._from not in Bots:
                 if wait["Mentionkick"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in Bots:
                           #cl.sendMessage(msg.to,"j̸͟͞a̸͟͞n̸͟͞g̸͟͞a̸͟͞n̸͟͞ t̸͟͞a̸͟͞g̸͟͞ g̸͟͞u̸͟͞a̸͟͞ n̸͟͞a̸͟͞n̸͟͞t̸͟͞i̸͟͞ k̸͟͞e̸͟͞j̸͟͞i̸͟͞t̸͟͞a̸͟͞k̸͟͞")
                           data = {
                               "type": "text",
                               "text": "j̸͟͞a̸͟͞n̸͟͞g̸͟͞a̸͟͞n̸͟͞ t̸͟͞a̸͟͞g̸͟͞ g̸͟͞u̸͟͞a̸͟͞ n̸͟͞a̸͟͞n̸͟͞t̸͟͞i̸͟͞ k̸͟͞e̸͟͞j̸͟͞i̸͟͞t̸͟͞a̸͟͞k̸͟͞",
                               "sentBy": {
                                   "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                   "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                   "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                               }
                           }
                           cl.postTemplate(to, data)
                           cl.kickoutFromGroup(msg.to, [msg._from])
                           break
               if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["detectMention2"] == True:
                   contact = cl.getContact(msg._from)
                   name = re.findall(r'@(\w+)', msg.text)
                   image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention["M"] in mid:
                        #   cl.sendMessage(msg.to, wait["Respontag2"])
                          # cl.sendImageWithURL(msg.to, image)
                          # cl.sendMessage(msg.to, None, contentMetadata={"STKID":"80543416","STKPKGID":"4582339","STKVER":"1"}, contentType=7)
                         #  cl.sendMention(sender, "pr๏ʍ๏ @!         \n┌──────────────────┐\n│     🔳 OPEN ORDER 🔳 \n├──────────────────\n│🎧FITUR LINE & SMULE🎤\n├──────────────────\n┝[]►Coin Line\n┝[]►Coin Gift\n┝[]►Vip Smule Android\n┝[]►Beku Akun Smule\n┝[]►Follower Smule\n┝[]►Songbook Smule\n│☛🏧Via Bank & Pulsa📱\n│♛♛♛♛♛♛♛♛♛♛♛♛♛♛\n├──────────────────\n│⚙️PROTECT & SELFBOT 🔧\n├──────────────────\n┝[]►Selfbot Only\n┝[]►Selfbot Only + Ajs\n┝[]►Selfbot Template\n┝[]►Selfbot Template + Ajs\n┝[]►Bot Protect Rom Smule\n┝[]►Bot Protect Rom Event\n│☛If Order Creator:\n│http://line.me/ti/p/~greetolala990\n│♛♛♛♛♛♛♛♛♛♛♛♛♛♛\n├──────────────────\n│Suport:⭕GʀᴇᴛQᴜᴇᴇɴ Sʜᴏᴘ⭕\n└──────────────────", [sender])
                           data = {
                               "type": "text",
                               "text": wait["Respontag2"],
                               "sentBy": {
                                   "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                   "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                   "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                               }
                           }
                           cl.postTemplate(to, data)
                           cl.sendMessage(msg.to, None, contentMetadata={"STKID":"80543416","STKPKGID":"4582339","STKVER":"1"}, contentType=7)
                           cl.sendMention(sender, "pr๏ʍ๏ @!         \n┌──────────────────┐\n│     🔳 OPEN ORDER 🔳 \n├──────────────────\n│🎧FITUR LINE & SMULE🎤\n├──────────────────\n┝[]►Coin Line\n┝[]►Coin Gift\n┝[]►Vip Smule Android\n┝[]►Beku Akun Smule\n┝[]►Follower Smule\n┝[]►Songbook Smule\n│☛🏧Via Bank & Pulsa📱\n│♛♛♛♛♛♛♛♛♛♛♛♛♛♛\n├──────────────────\n│⚙️PROTECT & SELFBOT 🔧\n├──────────────────\n┝[]►Selfbot Only\n┝[]►Selfbot Only + Ajs\n┝[]►Selfbot Template\n┝[]►Selfbot Template + Ajs\n┝[]►Bot Protect Rom Smule\n┝[]►Bot Protect Rom Event\n│☛If Order Creator:\n│http://line.me/ti/p/~greetolala990\n│♛♛♛♛♛♛♛♛♛♛♛♛♛♛\n├──────────────────\n│Suport:⭕GʀᴇᴛQᴜᴇᴇɴ Sʜᴏᴘ⭕\n└──────────────────", [sender])
                           break
               if msg.contentType == 7:
                 if wait["sticker"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,"「Cek ID Sticker」\n°❂° STKID : " + msg.contentMetadata["STKID"] + "\n°❂° STKPKGID : " + msg.contentMetadata["STKPKGID"] + "\n°❂° STKVER : " + msg.contentMetadata["STKVER"]+ "\n\n「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        cl.sendMessage(msg.to,"°❂° Nama : " + msg.contentMetadata["displayName"] + "\n°❂° MID : " + msg.contentMetadata["mid"] + "\n°❂° Status Msg : " + contact.statusMessage + "\n°❂° Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        cl.sendImageWithURL(msg.to, image)
        if op.type == 25 or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 and msg.toType == 2:
                if sender != cl.profile.mid:
                    to = sender
                else:
                    to = receiver
            elif msg.toType == 1:
                to = receiver
            elif msg.toType == 2:
                to = receiver
            if msg.contentType == 0:
                to = receiver
            if msg.contentType == 16:
              if settings["checkPost"] == True:
                url = msg.contentMetadata["postEndUrl"]
                cl.likePost(url[25:58], url[66:], likeType=1004)
                cl.createComment(url[25:58], url[66:], wait["comment"])
                #cl.sendMessage(msg.to,"✪[]► Like Success")
                data = {
                    "type": "text",
                    "text": "[✪]►ᴅᴏɴᴇ ʟɪᴋᴇ ᴘᴏsᴛ",
                    "sentBy": {
                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                    }
                }
                cl.postTemplate(to, data)
            if msg.contentType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
               if msg.contentType == 7:
                 if wait["sticker"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,"STKID : " + msg.contentMetadata["STKID"] + "\nSTKPKGID : " + msg.contentMetadata["STKPKGID"] + "\nSTKVER : " + msg.contentMetadata["STKVER"]+ "\n\n「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        cl.sendMessage(msg.to,"Nama : " + msg.contentMetadata["displayName"] + "\nMID : " + msg.contentMetadata["mid"] + "\nStatus Msg : " + contact.statusMessage + "\nPicture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        cl.sendImageWithURL(msg.to, image)
               if msg.contentType == 13:
                if msg._from in admin:
                  if wait["invite"] == True:
                    msg.contentType = 0
                    contact = cl.getContact(msg.contentMetadata["mid"])
                    invite = msg.contentMetadata["mid"]
                    groups = cl.getGroup(msg.to)
                    pending = groups.invitee
                    targets = []
                    for s in groups.members:
                        if invite in wait["blacklist"]:
                            cl.sendMessage(msg.to, "ʟɪsᴛ ʙʟ")
                            break
                        else:
                            targets.append(invite)
                    if targets == []:
                        pass
                    else:
                         for target in targets:
                             try:
                                  cl.findAndAddContactsByMid(target)
                                  cl.inviteIntoGroup(msg.to,[target])
                                  ryan = cl.getContact(target)
                                  zx = ""
                                  zxc = ""
                                  zx2 = []
                                  xpesan =  "「 sᴜᴋsᴇs ɪɴᴠɪᴛᴇ 」\nɴᴀᴍᴀ"
                                  ret_ = "ᴋᴇᴛɪᴋ ɪɴᴠɪᴛᴇ ᴏғғ ᴊɪᴋᴀ sᴜᴅᴀʜ ᴅᴏɴᴇ"
                                  ry = str(ryan.displayName)
                                  pesan = ''
                                  pesan2 = pesan+"@x\n"
                                  xlen = str(len(zxc)+len(xpesan))
                                  xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                  zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                  zx2.append(zx)
                                  zxc += pesan2
                                  text = xpesan + zxc + ret_ + ""
                                  cl.sendMessage(msg.to, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                  wait["invite"] = False
                                  break
                             except:
                                 # cl.sendMessage(msg.to,"ᴀɴᴅᴀ ᴛᴇʀᴋᴇɴᴀ sᴛʀᴜᴋ")
                                  data = {
                                      "type": "text",
                                      "text": "Anda Terkena Struk",
                                      "sentBy": {
                                          "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                          "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                          "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                      }
                                  }
                                  cl.postTemplate(to, data)
                                  wait["invite"] = False
                                  break
                                  
               if msg.contentType == 13:
                 if wait["Invi"] == True:
                        _name = msg.contentMetadata["displayName"]
                        invite = msg.contentMetadata["mid"]
                        groups = cl.getGroup(msg.to)
                        pending = groups.invitee
                        targets = []
                        for s in groups.members:
                            if _name in s.displayName:
                                cl.sendMessage(msg.to,"-> " + _name + " was here")
                                wait["Invi"] = False
                                break         
                            else:
                                targets.append(invite)
                        if targets == []:
                            pass
                        else:
                            for target in targets:
                                cl.findAndAddContactsByMid(target)
                                cl.inviteIntoGroup(msg.to,[target])
                                cl.sendMessage(msg.to,"ᴅᴏɴᴇ ɴɢɪɴᴠɪᴛ ᴊᴏᴍʙʟᴏ ɪɴɪ \n➡" + _name)
                                wait["Invi"] = False
                                break
#=============MEDIA FOTOBOT=============
               if msg.contentType == 7:
                  if msg._from in mid:
                     if settings["AddstickerTag"]["status"] == True:
                         settings["AddstickerTag"]["sid"] = msg.contentMetadata["STKID"]
                         settings["AddstickerTag"]["spkg"] = msg.contentMetadata["STKPKGID"]
                        # cl.sendMessage(msg.to, "Sticker respon hasben changed")
                         data = {
                             "type": "text",
                             "text": "Sticker respon hasben changed",
                             "sentBy": {
                                 "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                 "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                 "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                             }
                         }
                         cl.postTemplate(to, data)
                         settings["AddstickerTag"]["status"] = False                       
               if msg.toType == 2:
                  if settings["changeCover"] == True:
                      path = cl.downloadObjectMsg(msg_id, saveAs="LineAPI/tmp/{}-cv.bin".format(time.time()))
                      settings["changeCover"] = False
                      cl.updateProfileCover(path)
                     # cl.sendMessage(to, "Berhasil mengubah cover profile")
                      data = {
                          "type": "text",
                          "text": "Success mengubah cover profile",
                          "sentBy": {
                              "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                              "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                              "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                          }
                      }
                      cl.postTemplate(to, data)
                      cl.deleteFile(path)       
               if msg.contentType == 2:
                   if msg._from in admin:
                       if msg._from in settings["ChangeVideoProfilevid"]:
                            settings["ChangeVideoProfilePicture"][msg._from] = True
                            del settings["ChangeVideoProfilevid"][msg._from]
                            cl.downloadObjectMsg(msg_id,'path','video.mp4')
                           # cl.sendMessage(msg.to,"Send gambarnya...")
                            data = {
                                "type": "text",
                                "text": "Send fotonya",
                                "sentBy": {
                                    "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                    "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                    "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                }
                            }
                            cl.postTemplate(to, data)
               if msg.contentType == 1:
                   if msg._from in admin:
                       if msg._from in settings["ChangeVideoProfilePicture"]:
                            del settings["ChangeVideoProfilePicture"][msg._from]
                            cl.downloadObjectMsg(msg_id,'path','image.jpg')
                            cl.nadyacantikimut('video.mp4','image.jpg')
                            #cl.sendMessage(msg.to,"Change Video Profile Success!!!")
                            data = {
                                "type": "text",
                                "text": "Change Video Profile Success",
                                "sentBy": {
                                    "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                    "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                    "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                }
                            }
                            cl.postTemplate(to, data)
               if msg.contentType == 1:
                  if msg._from in admin:
                     if settings["Addimage"]["status"] == True:
                         path = cl.downloadObjectMsg(msg.id)
                         images[settings["Addimage"]["name"]] = str(path)
                         f = codecs.open("image.json","w","utf-8")
                         json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                         cl.sendMessage(msg.to, "Berhasil menambahkan gambar {}".format(str(settings["Addimage"]["name"])))
                         settings["Addimage"]["status"] = False
                         settings["Addimage"]["name"] = ""
               if msg.contentType == 2:
                  if msg._from in admin:
                     if settings["Addvideo"]["status"] == True:
                         path = cl.downloadObjectMsg(msg.id)
                         videos[settings["Addvideo"]["name"]] = str(path)
                         f = codecs.open("video.json","w","utf-8")
                         json.dump(videos, f, sort_keys=True, indent=4, ensure_ascii=False)
                         cl.sendMessage(msg.to, "Berhasil menambahkan video {}".format(str(settings["Addvideo"]["name"])))
                         settings["Addvideo"]["status"] = False
                         settings["Addvideo"]["name"] = ""
               if msg.contentType == 7:
                  if msg._from in admin:
                     if settings["Addsticker"]["status"] == True:
                         stickers[settings["Addsticker"]["name"]] = {"STKID":msg.contentMetadata["STKID"],"STKPKGID":msg.contentMetadata["STKPKGID"]}
                         f = codecs.open("sticker.json","w","utf-8")
                         json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                         cl.sendMessage(msg.to, "Berhasil menambahkan sticker {}".format(str(settings["Addsticker"]["name"])))
                         settings["Addsticker"]["status"] = False
                         settings["Addsticker"]["name"] = ""
               if msg.contentType == 3:
                  if msg._from in admin:
                     if settings["Addaudio"]["status"] == True:
                         path = cl.downloadObjectMsg(msg.id)
                         audios[settings["Addaudio"]["name"]] = str(path)
                         f = codecs.open("audio.json","w","utf-8")
                         json.dump(audios, f, sort_keys=True, indent=4, ensure_ascii=False)
                         cl.sendMessage(msg.to, "Berhasil menambahkan mp3 {}".format(str(settings["Addaudio"]["name"])))
                         settings["Addaudio"]["status"] = False
                         settings["Addaudio"]["name"] = ""
               if msg.contentType == 0:
                  if settings["autoRead"] == True:
                      cl.sendChatChecked(msg.to, msg_id)
                  if text is None:
                      return
                  else:
                         for sticker in stickers:
                            if text.lower() == sticker:
                               sid = stickers[text.lower()]["STKID"]
                               spkg = stickers[text.lower()]["STKPKGID"]
                               cl.sendSticker(to, spkg, sid)
                         for image in images:
                            if text.lower() == image:
                               cl.sendImage(msg.to, images[image])
                         for audio in audios:
                            if text.lower() == audio:
                               cl.sendAudio(msg.to, audios[audio])
                         for video in videos:
                            if text.lower() == video:
                               cl.sendVideo(msg.to, videos[video])
               if msg.contentType == 13:
                 if msg._from in owner:
                  if wait["addbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        cl.sendMessage(msg.to,"Already in bot")
                        wait["addbots"] = True
                    else:
                        Bots.append(msg.contentMetadata["mid"])
                        wait["addbots"] = True
                        sendTextTemplate1(msg.to,"Succes add bot")
                 if wait["dellbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        Bots.remove(msg.contentMetadata["mid"])
                        cl.sendMessage(msg.to,"Succes delete bot")
                    else:
                        wait["dellbots"] = True
                        cl.sendMessage(msg.to,"Nothing in bot")
#ADD STAFF
                 if msg._from in admin:
                  if wait["addstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        cl.sendMessage(msg.to,"✅Contact itu sudah jadi staff")
                        wait["addstaff"] = True
                    else:
                        staff.append(msg.contentMetadata["mid"])
                        wait["addstaff"] = True
                        cl.sendMessage(msg.to,"✅Berhasil menambahkan ke staff")
                 if wait["dellstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        staff.remove(msg.contentMetadata["mid"])
                        cl.sendMessage(msg.to,"✅Berhasil menghapus dari staff")
                        wait["dellstaff"] = True
                    else:
                        wait["dellstaff"] = True
                        cl.sendMessage(msg.to,"❎Contact itu bukan staff")
#ADD ADMIN
                 if msg._from in admin:
                  if wait["addadmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        cl.sendMessage(msg.to,"✅Contact itu sudah jadi admin")
                        wait["addadmin"] = True
                    else:
                        admin.append(msg.contentMetadata["mid"])
                        wait["addadmin"] = True
                        cl.sendMessage(msg.to,"✅Berhasil menambahkan ke admin")
                 if wait["delladmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        admin.remove(msg.contentMetadata["mid"])
                        cl.sendMessage(msg.to,"✅Berhasil menghapus dari admin")
                    else:
                        wait["delladmin"] = True
                        cl.sendMessage(msg.to,"❎Contact itu bukan admin")
#ADD BLACKLIST
                 if msg._from in admin:
                  if wait["wblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        cl.sendMessage(msg.to,"❎Contact itu sudah ada di blacklist")
                        wait["wblacklist"] = True
                    else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["wblacklist"] = True
                        cl.sendMessage(msg.to,"✅Berhasil menambahkan ke blacklist user")
                  if wait["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        cl.sendMessage(msg.to,"✅Berhasil menghapus dari blacklist user")
                    else:
                        wait["dblacklist"] = True
                        cl.sendMessage(msg.to,"❎Contact itu tidak ada di blacklist")
#TALKBAN
                 if msg._from in admin:
                  if wait["Talkwblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        cl.sendMessage(msg.to,"✅Contact itu sudah ada di Talkban")
                        wait["Talkwblacklist"] = True
                    else:
                        wait["Talkblacklist"][msg.contentMetadata["mid"]] = True
                        wait["Talkwblacklist"] = True
                        cl.sendMessage(msg.to,"✅Berhasil menambahkan ke Talkban user")
                  if wait["Talkdblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        del wait["Talkblacklist"][msg.contentMetadata["mid"]]
                        cl.sendMessage(msg.to,"✅Berhasil menghapus dari Talkban user")
                    else:
                        wait["Talkdblacklist"] = True
                        cl.sendMessage(msg.to,"❎Contact itu tidak ada di Talkban")
#UPDATE FOTO
               if msg.contentType == 1:
                 if msg._from in owner:
                    if Setmain["Addimage"] == True:
                        msgid = msg.id
                        fotoo = "https://obs.line-apps.com/talk/m/download.nhn?oid="+msgid
                        headers = cl.Talk.Headers
                        r = requests.get(fotoo, headers=headers, stream=True)
                        if r.status_code == 200:
                            path = os.path.join(os.path.dirname(__file__), 'dataPhotos/%s.jpg' % Setmain["Img"])
                            with open(path, 'wb') as fp:
                                shutil.copyfileobj(r.raw, fp)
                            #cl.sendMessage(msg.to, "Succes add picture")
                            data = {
                                "type": "text",
                                "text": "Succes add picture",
                                "sentBy": {
                                    "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                    "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                    "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                }
                            }
                            cl.postTemplate(to, data)
                        Setmain["Img"] = {}
                        Setmain["Addimage"] = False
               if msg.contentType == 2:
               	if settings["changevp"] == True:
               		contact = cl.getProfile()
               		path = cl.downloadFileURL("https://obs.line-scdn.net/{}".format(contact.pictureStatus))
               		path1 = cl.downloadObjectMsg(msg_id)
               		settings["changevp"] = False
               		changeVideoAndPictureProfile(path, path1)
               		cl.sendMessage(to, "Success change video profile")
               if msg.contentType == 2:
                 if msg._from in owner or msg._from in admin or msg._from in staff:
                   if settings["groupPicture"] == True:
                     path = cl.downloadObjectMsg(msg_id)
                     settings["groupPicture"] = False
                     cl.updateGroupPicture(msg.to, path)
                     #cl.sendMessage(msg.to, "Succes change pict group")
                     data = {
                         "type": "text",
                         "text": "success change pict grup",
                         "sentBy": {
                             "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                             "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                             "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                         }
                     }
                     cl.postTemplate(to, data)
               if msg.contentType == 1:
                 if msg._from in admin:
                   if settings["changePicture"] == True:
                     path1 = k1.downloadObjectMsg(msg_id)
                     path2 = k2.downloadObjectMsg(msg_id)
                     path3 = sw.downloadObjectMsg(msg_id)
                     settings["changePicture"] = False
                     k1.updateProfilePicture(path1)
                     k1.sendMessage(msg.to, "✓ᴘʀᴏғɪʟᴇ ᴘʜᴏᴛᴏ\nsᴜᴄᴄᴇssғᴜʟʟʏ ᴄʜᴀɴɢᴇᴅ")
                     k2.updateProfilePicture(path2)
                     k2.sendMessage(msg.to, "✓ᴘʀᴏғɪʟᴇ ᴘʜᴏᴛᴏ\nsᴜᴄᴄᴇssғᴜʟʟʏ ᴄʜᴀɴɢᴇᴅ")
                     sw.updateProfilePicture(path3)
                     sw.sendMessage(msg.to, "✓ᴘʀᴏғɪʟᴇ ᴘʜᴏᴛᴏ\nsᴜᴄᴄᴇssғᴜʟʟʏ ᴄʜᴀɴɢᴇᴅ")

               if msg.contentType == 1:
                 if msg._from in admin:
                   if settings["changePicture"] == True:
                     path5 = cl.downloadObjectMsg(msg_id)
                     settings["changePicture"] = False
                     cl.updateProfilePicture(path5)
                    # cl.sendMessage(msg.to, "Berhasil mengubah foto profile bot")
                     data = {
                         "type": "text",
                         "text": "success change pict bot",
                         "sentBy": {
                             "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                             "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                             "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                         }
                     }
                     cl.postTemplate(to, data)
               if msg.contentType == 1:
                 if msg._from in admin:
                        if mid in Setmain["RAfoto"]:
                            path = cl.downloadObjectMsg(msg_id)
                            del Setmain["RAfoto"][mid]
                            cl.updateProfilePicture(path)
                          #  cl.sendMessage(msg.to,"ғᴏᴛᴏ ʙᴇʀʜᴀsɪʟ ᴅɪ'ʀᴜʙᴀʜ")
                            data = {
                                "type": "text",
                                "text": "ғᴏᴛᴏ ʙᴇʀʜᴀsɪʟ ᴅɪ'ʀᴜʙᴀʜ",
                                "sentBy": {
                                    "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                    "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                    "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                }
                            }
                            cl.postTemplate(to, data)
                        if Amid in Setmain["RAfoto"]:
                            path = k1.downloadObjectMsg(msg_id)
                            del Setmain["RAfoto"][Amid]
                            k1.updateProfilePicture(path)
                          #  cl.sendMessage(msg.to,"ғᴏᴛᴏ ʙᴇʀʜᴀsɪʟ ᴅɪ'ʀᴜʙᴀʜ")
                            data = {
                                "type": "text",
                                "text": "ғᴏᴛᴏ ʙᴇʀʜᴀsɪʟ ᴅɪ'ʀᴜʙᴀʜ",
                                "sentBy": {
                                    "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                    "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                    "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                }
                            }
                            k1.postTemplate(to, data)
                        if Bmid in Setmain["RAfoto"]:
                            path = k2.downloadObjectMsg(msg_id)
                            del Setmain["RAfoto"][Bmid]
                            k2.updateProfilePicture(path)
                          #  cl.sendMessage(msg.to,"ғᴏᴛᴏ ʙᴇʀʜᴀsɪʟ ᴅɪ'ʀᴜʙᴀʜ")
                            data = {
                                "type": "text",
                                "text": "ғᴏᴛᴏ ʙᴇʀʜᴀsɪʟ ᴅɪ'ʀᴜʙᴀʜ",
                                "sentBy": {
                                    "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                    "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                    "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                }
                            }
                            k2.postTemplate(to, data)
                        if Zmid in Setmain["RAfoto"]:
                            path = sw.downloadObjectMsg(msg_id)
                            del Setmain["RAfoto"][Zmid]
                            sw.updateProfilePicture(path)
                          #  cl.sendMessage(msg.to,"ғᴏᴛᴏ ʙᴇʀʜᴀsɪʟ ᴅɪ'ʀᴜʙᴀʜ")
                            data = {
                                "type": "text",
                                "text": "ғᴏᴛᴏ ʙᴇʀʜᴀsɪʟ ᴅɪ'ʀᴜʙᴀʜ",
                                "sentBy": {
                                    "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                    "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                    "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                }
                            }
                            sw.postTemplate(to, data)

               if msg.contentType == 0:
                    if Setmain["autoRead"] == True:
                        cl.sendChatChecked(msg.to, msg_id)
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                        if cmd == "help":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               helpMessage = help()
                               #cl.sendMessage(msg.to, str(helpMessage))
                               data = {
                                "type": "text",
                                "text": "{}".format(str(helpMessage)),
                                "sentBy": {
                                    "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                    "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                    "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                }
                            }
                            cl.postTemplate(to, data)
                        if cmd == "bot on":
                            if msg._from in admin:
                                wait["selfbot"] = True
                               # cl.sendMessage(msg.to, "Selfbot diaktifkan")
                                data = {
                                "type": "text",
                                "text": "☂Selfbot diaktifkan",
                                "sentBy": {
                                    "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                    "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                    "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                }
                            }
                            cl.postTemplate(to, data)
                        elif cmd == "bot off":
                            if msg._from in admin:
                                wait["selfbot"] = False
                               # cl.sendMessage(msg.to, "Selfbot dinonaktifkan")
                                data = {
                                "type": "text",
                                "text": "☂Selfbot dinonaktifkan",
                                "sentBy": {
                                    "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                    "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                    "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                }
                            }
                            cl.postTemplate(to, data)
                        elif cmd == "help creator":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               helpMessage1 = helpcreator()
                             #  cl.sendMessage(msg.to, str(helpMessage1))
                               data = {
                                "type": "text",
                                "text": "{}".format(str(helpMessage1)),
                                "sentBy": {
                                    "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                    "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                    "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                }
                            }
                            cl.postTemplate(to, data)
                        elif cmd == "help setting":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               helpMessage2 = helpsetting()
                               #cl.sendMessage(msg.to, str(helpMessage2))
                               data = {
                                "type": "text",
                                "text": "{}".format(str(helpMessage2)),
                                "sentBy": {
                                    "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                    "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                    "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                }
                            }
                            cl.postTemplate(to, data)
                        elif cmd == "help media":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               helpMessage3 = media()
                               #cl.sendMessage(msg.to, str(helpMessage3))
                               data = {
                                "type": "text",
                                "text": "{}".format(str(helpMessage3)),
                                "sentBy": {
                                    "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                    "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                    "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                }
                            }
                            cl.postTemplate(to, data)
                        elif cmd == "help group":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               helpMessage4 = helpgroup()       
                              # cl.sendMessage(msg.to, str(helpMessage4))
                               data = {
                                "type": "text",
                                "text": "{}".format(str(helpMessage4)),
                                "sentBy": {
                                    "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                    "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                    "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                }
                            }
                            cl.postTemplate(to, data)
                        elif cmd == "help admin":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               helpMessage5 = helpadmin()
                               #cl.sendMessage(msg.to, str(helpMessage5))
                               data = {
                                "type": "text",
                                "text": "{}".format(str(helpMessage5)),
                                "sentBy": {
                                    "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                    "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                    "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                }
                            }
                            cl.postTemplate(to, data)
                            
                        elif cmd == "help ghost":
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin or msg._from in staff:
                               helpMessage6 = helpghost()
                               data = {
                                "type": "text",
                                "text": "{}".format(str(helpMessage6)),
                                "sentBy": {
                                    "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                    "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                    "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                }
                            }
                            cl.postTemplate(to, data)
                               
                        elif cmd == "changevp":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                            	settings["changevp"] = True
                            	#cl.sendMessage(to, "SHARE VIDEO PROFILE\nKIRIM VIDEONYA SAY")
                            data = {
                                "type": "text",
                                "text": "KIRIM VIDEONYA SAY",
                                "sentBy": {
                                    "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                    "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                    "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                }
                            }
                            cl.postTemplate(to, data)

                        elif cmd == "creator":
                          if wait["selfbot"] == True:
                        #    if msg._from in admin:
                             #  cl.sendMessage(msg.to, "╔═══════════\n""║║⏺️ɴᴀᴍᴀ: ɢʀᴇᴇᴛʙᴏᴛᴢ\n""║║⏺️ᴅᴏᴍɪsɪʟɪ: ʙʀᴇʙᴇs\n""║║⏺ᴘʀᴏᴠɪɴsɪ: ᴊᴀᴛᴇɴɢ\n""║║⏺️ɴᴇɢᴀʀᴀ: ɪɴᴅᴏɴᴇsɪᴀ\n""║║⏺️ɪᴅʟɪɴᴇ: ɢʀᴇᴇᴛᴏʟᴀʟᴀ990\n""║║⏺️sᴍᴜʟᴇ: __ᴛʀsᴄ_ᴏʟᴀʟᴀ__\n""╚═══════════")
                               data = {
                                   "type": "text",
                                   "text": "╔═══════════\n""║║⏺️ɴᴀᴍᴀ: ɢʀᴇᴇᴛʙᴏᴛᴢ\n""║║⏺️ᴅᴏᴍɪsɪʟɪ: ʙʀᴇʙᴇs\n""║║⏺ᴘʀᴏᴠɪɴsɪ: ᴊᴀᴛᴇɴɢ\n""║║⏺️ɴᴇɢᴀʀᴀ: ɪɴᴅᴏɴᴇsɪᴀ\n""║║⏺️ɪᴅʟɪɴᴇ: sʟᴀɴᴋᴇʀ123456\n""║║⏺️sᴍᴜʟᴇ: __ᴛʀsᴄ_ᴏʟᴀʟᴀ__\n""╚═══════════",
                                   "sentBy": {
                                       "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                       "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                       "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                   }
                               }
                               cl.postTemplate(to, data)

                        elif text.lower() == "setting":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                md = ""
                                if settings["checkPost"] == True: md+="│⏺️ ᴘᴏsᴛ : ✅\n"
                                else: md+="│⏺️ ᴘᴏsᴛ : ❌\n"
                                if wait["likeOn"] == True: md+="│⏺️ ʟɪᴋᴇ : ✅\n"
                                else: md+="│⏺️ ʟɪᴋᴇ : ❌\n"
                                if wait["contact"] == True: md+="│⏺️ ᴄᴏɴᴛᴀᴄᴛ : ✅\n"
                                else: md+="│⏺️ ᴄᴏɴᴛᴀᴄᴛ : ❌\n"
                                if wait["Mentionkick"] == True: md+="│⏺️ ɴᴏᴛᴀɢ : ✅\n"
                                else: md+="│⏺️ ɴᴏᴛᴀɢ : ❌\n"
                                if wait["sticker"] == True: md+="│⏺️ sᴛɪᴄᴋᴇʀ : ✅\n"
                                else: md+="│⏺️ sᴛɪᴄᴋᴇʀ :❌\n"
                                if wait["Unsend"] == True: md+="│⏺️ ᴜɴsᴇɴᴅ : ✅\n"
                                else: md+="│⏺️ ᴜɴsᴇɴᴅ : ❌\n"
                                if wait["autoAdd"] == True: md+="│⏺️ ᴀᴜᴛᴏᴀᴅᴅ : ✅\n"
                                else: md+="│⏺️ ᴀᴜᴛᴏᴀᴅᴅ : ❌\n"
                                if wait["autoLeave"] == True: md+="│⏺️ ᴀᴜᴛᴏʟᴇᴀᴠᴇ : ✅\n"
                                else: md+="│⏺️ ᴀᴜᴛᴏʟᴇᴀᴠᴇ : ❌\n"
                                if wait["autoJoin"] == True: md+="│⏺️ ᴀᴜᴛᴏᴊᴏɪɴ : ✅\n"
                                else: md+="│⏺️ ᴀᴜᴛᴏᴊᴏɪɴ : ❌\n"
                                if settings["autoJoinTicket"] == True: md+="│⏺️ ᴊᴏɪɴᴛɪᴄᴋᴇᴛ : ✅\n"
                                else: md+="│⏺️ ᴊᴏɪɴᴛɪᴄᴋᴇᴛ : ❌\n"
                                if wait["autoReject"] == True: md+="│⏺️ ᴀᴜᴛᴏʀᴇᴊᴇᴄᴛ : ✅\n"
                                else: md+="│⏺️ ᴀᴜᴛᴏʀᴇᴊᴇᴄᴛ : ❌\n"
                                if wait["autoBlock"] == True: md+="│⏺️ ᴀᴜᴛᴏʙʟᴏᴄᴋ : ✅\n"
                                else: md+="│⏺️ ᴀᴜᴛᴏʙʟᴏᴄᴋ : ❌\n"
                                if settings["welcome"] == True: md+="│⏺️ ᴡᴇʟᴄᴏᴍᴇ : ✅\n"
                                else: md+="│⏺️ ᴡᴇʟᴄᴏᴍᴇ : ❌\n"
                                if wait["detectMention"] == True: md+="│⏺️ ʀᴇsᴘᴏɴᴛᴀɢ : ✅\n"
                                else: md+="│⏺️ ʀᴇsᴘᴏɴᴛᴀɢ : ❌\n"
                                if wait["detectMention2"] == True: md+="│⏺️ ʀᴇsᴘᴏɴᴛᴀɢ² : ✅\n"
                                else: md+="│⏺️ ʀᴇsᴘᴏɴᴛᴀɢ² : ❌\n"
                               # cl.sendMessage(msg.to, "╔═══════════\n"+ md +"╚═══════════")
                                data = {
                                    "type": "text",
                                    "text": "╭「⏺️sᴛᴀᴛᴜs ʙᴏᴛ⏺️」\n"+ md +"╰「⏺️sᴇʟғ ᴘʏᴛʜᴏɴ³⏺️」",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
#friendlist
                        elif cmd == "listfriend": 
                          if msg._from in admin:
                            contactlist = cl.getAllContactIds()
                            kontak = cl.getContacts(contactlist)
                            num=1
                            msgs="『FRIENDLIST』\n\n"
                            for ids in kontak:
                                msgs+="\n%i. %s" % (num, ids.displayName)
                                num=(num+1)
                            msgs+="\n\nTotal Friend : %i" % len(kontak)
                            cl.sendMessage(to, msgs)
                   
                        elif cmd == "me" or text.lower() == '.me':
                          if wait["selfbot"] == True:
                                msg.contentType = 13
                                msg.contentMetadata = {'mid': msg._from}
                                cl.sendMessage(msg.to, None, contentMetadata={'mid': msg._from}, contentType=13)
                                path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                                image = 'http://dl.profile.line.naver.jp'+path
                                cl.sendImageWithURL(msg.to, image)

                        elif cmd.startswith("leaveall "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getGroup(group)
                                try:
                                    cl.leaveGroup(group)
                                    gCreator = G.creator.mid
                                except:
                                    cl.sendMessage(msg.to, "Grup itu tidak ada")
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ginfo = cl.getGroup(group)
                                gCreator = ginfo.creator.mid
                                reck = cl.getContact(gCreator)
                                zx = ""
                                zxc = ""
                                zx2 = []
                                xpesan = '【 Sukses Leave Group 】\n• Creator :  '
                                recky = str(reck.displayName)
                                pesan = ''
                                pesan2 = pesan+"@x\n"
                                xlen = str(len(zxc)+len(xpesan))
                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                zx = {'S':xlen, 'E':xlen2, 'M':reck.mid}
                                zx2.append(zx)
                                zxc += pesan2
                                ret_ += xpesan +zxc
                                ret_ += "• Nama grup : {}".format(G.name)
                                ret_ += "\n• Pendingan : {}".format(gPending)
                                ret_ += "\n• Jumlah Member : {}".format(str(len(G.members)))
                                cl.sendMessage(receiver, ret_, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                            except Exception as e:
                                cl.sendMessage(to, str(e))
     
    #joinall command dari luar group

                        elif cmd.startswith(".join "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getGroup(group)
                                G.preventedJoinByTicket = False
                                cl.updateGroup(G)
                                invsend = 0
                                Ticket = cl.reissueGroupTicket(group)
                                cl.acceptGroupInvitationByTicket(group,Ticket)
                                G.preventedJoinByTicket = True
                                cl.updateGroup(G)
                                try:
                                    gCreator = G.creator.mid
                                    dia = cl.getContact(gCreator)
                                    zx = ""
                                    zxc = ""
                                    zx2 = []
                                    xpesan = '【 Sukses Masuk Group 】\n• Creator :  '
                                    diaa = str(dia.displayName)
                                    pesan = ''
                                    pesan2 = pesan+"@a\n"
                                    xlen = str(len(zxc)+len(xpesan))
                                    xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':dia.mid}
                                    zx2.append(zx)
                                    zxc += pesan2
                                except:
                                    gCreator = "Tidak ditemukan"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(line.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += xpesan+zxc
                                ret_ += "• Nama grup : {}".format(G.name)
                                ret_ += "\n• Group Qr : {}".format(gQr)
                                ret_ += "\n• Pendingan : {}".format(gPending)
                                ret_ += "\n• Group Ticket : {}".format(gTicket)
                                ret_ += ""
                                cl.sendMessage(receiver, ret_, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                            except:
                                pass
                                
                        elif ".Invite" in msg.text:
                            if msg._from in admin:                                                                                                                                       
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]                                                                                                                                
                               targets = []
                               for x in key["MENTIONEES"]:                                                                                                                                  
                                   targets.append(x["M"])
                               for target in targets:                                                                                                                                       
                                   try:
                                      cl.findAndAddContactsByMid(target)
                                      cl.inviteIntoGroup(msg.to,[target])
                                   except:
                                       pass 
 
                        elif text.lower() == "mid":
                          if wait["selfbot"] == True:
                               middd = "Name : " +cl.getContact(msg._from).displayName + "\nMid : " +msg._from
                              # cl.sendMessage(msg.to,middd)
                               data = {
                                   "type": "text",
                                   "text": "{}".format(str(middd)),
                                   "sentBy": {
                                       "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                       "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                       "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                   }
                               }
                               cl.postTemplate(to, data)

                        elif text.lower() == 'assalamualaikum':
                             #  cl.sendMessage(msg.to, "Wa'alaikumsallam.Wr,Wb")
                               data = {
                                   "type": "text",
                                   "text": "Wa'alaikumsallam.Wr,Wb",
                                   "sentBy": {
                                       "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                       "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                       "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                   }
                               }
                               cl.postTemplate(to, data)

                        elif text.lower() == 'promo':
                        	   #cl.sendMessage(msg.to,"┌──────────────────┐\n│     🔳 OPEN ORDER 🔳 \n├──────────────────\n│🎧FITUR LINE & SMULE🎤\n├──────────────────\n┝[]►Coin Line\n┝[]►Coin Gift\n┝[]►Vip Smule Android\n┝[]►Beku Akun Smule\n┝[]►Follower Smule\n┝[]►Songbook Smule\n│☛🏧Via Bank & Pulsa📱\n│♛♛♛♛♛♛♛♛♛♛♛♛♛♛\n├──────────────────\n│⚙️PROTECT & SELFBOT 🔧\n├──────────────────\n┝[]►Selfbot Only\n┝[]►Selfbot Only + Ajs\n┝[]►Selfbot Template\n┝[]►Selfbot Template + Ajs\n┝[]►Bot Protect Rom Smule\n┝[]►Bot Protect Rom Event\n│☛If Order Creator:\n│http://line.me/ti/p/~greetolala990\n│♛♛♛♛♛♛♛♛♛♛♛♛♛♛\n├──────────────────\n│Suport:⭕GʀᴇᴛQᴜᴇᴇɴ Sʜᴏᴘ⭕\n└──────────────────")
                               data = {
                                   "type": "text",
                                   "text": "┌──────────────────┐\n│     🔳 OPEN ORDER 🔳 \n├──────────────────\n│🎧FITUR LINE & SMULE🎤\n├──────────────────\n┝[]►Coin Line\n┝[]►Coin Gift\n┝[]►Vip Smule Android\n┝[]►Beku Akun Smule\n┝[]►Follower Smule\n┝[]►Songbook Smule\n│☛🏧Via Bank & Pulsa📱\n│♛♛♛♛♛♛♛♛♛♛♛♛♛♛\n├──────────────────\n│⚙️PROTECT & SELFBOT 🔧\n├──────────────────\n┝[]►Selfbot Only\n┝[]►Selfbot Only + Ajs\n┝[]►Selfbot Template\n┝[]►Selfbot Template + Ajs\n┝[]►Bot Protect Rom Smule\n┝[]►Bot Protect Rom Event\n│☛If Order Creator:\n│http://line.me/ti/p/~slanker123456\n│♛♛♛♛♛♛♛♛♛♛♛♛♛♛\n├──────────────────\n│Suport:⭕GʀᴇᴛQᴜᴇᴇɴ Sʜᴏᴘ⭕\n└──────────────────",
                                   "sentBy": {
                                       "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                       "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                       "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                   }
                               }
                               cl.postTemplate(to, data)
                        elif text.lower() == 'order':
                        	  # cl.sendMessage(msg.to,"┌──────────────────┐\n│     🔳 OPEN ORDER 🔳 \n├──────────────────\n│🎧FITUR LINE & SMULE🎤\n├──────────────────\n┝[]►Coin Line\n┝[]►Coin Gift\n┝[]►Vip Smule Android\n┝[]►Beku Akun Smule\n┝[]►Follower Smule\n┝[]►Songbook Smule\n│☛🏧Via Bank & Pulsa📱\n│♛♛♛♛♛♛♛♛♛♛♛♛♛♛\n├──────────────────\n│⚙️PROTECT & SELFBOT 🔧\n├──────────────────\n┝[]►Selfbot Only\n┝[]►Selfbot Only + Ajs\n┝[]►Selfbot Template\n┝[]►Selfbot Template + Ajs\n┝[]►Bot Protect Rom Smule\n┝[]►Bot Protect Rom Event\n│☛If Order Creator:\n│http://line.me/ti/p/~greetolala990\n│♛♛♛♛♛♛♛♛♛♛♛♛♛♛\n├──────────────────\n│Suport:⭕GʀᴇᴛQᴜᴇᴇɴ Sʜᴏᴘ⭕\n└──────────────────")
                               data = {
                                   "type": "text",
                                   "text": "┌──────────────────┐\n│     🔳 OPEN ORDER 🔳 \n├──────────────────\n│🎧FITUR LINE & SMULE🎤\n├──────────────────\n┝[]►Coin Line\n┝[]►Coin Gift\n┝[]►Vip Smule Android\n┝[]►Beku Akun Smule\n┝[]►Follower Smule\n┝[]►Songbook Smule\n│☛🏧Via Bank & Pulsa📱\n│♛♛♛♛♛♛♛♛♛♛♛♛♛♛\n├──────────────────\n│⚙️PROTECT & SELFBOT 🔧\n├──────────────────\n┝[]►Selfbot Only\n┝[]►Selfbot Only + Ajs\n┝[]►Selfbot Template\n┝[]►Selfbot Template + Ajs\n┝[]►Bot Protect Rom Smule\n┝[]►Bot Protect Rom Event\n│☛If Order Creator:\n│http://line.me/ti/p/~slanker123456\n│♛♛♛♛♛♛♛♛♛♛♛♛♛♛\n├──────────────────\n│Suport:⭕GʀᴇᴛQᴜᴇᴇɴ Sʜᴏᴘ⭕\n└──────────────────",
                                   "sentBy": {
                                       "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                       "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                       "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                   }
                               }
                               cl.postTemplate(to, data)

                        elif ("Gname " in msg.text):
                          if msg._from in admin:
                              X = cl.getGroup(msg.to)
                              X.name = msg.text.replace("Gname ","")
                              cl.updateGroup(X)

                        elif "Gruppict" in msg.text:
                          if msg._from in admin:
                                group = cl.getGroup(msg.to)
                                path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                                cl.sendImageWithURL(msg.to,path)

                        elif "Getprofile " in msg.text:
                          if msg._from in admin:
                            if 'MENTION' in msg.contentMetadata.keys() != None:
                                names = re.findall(r'@(\w+)', msg.text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                for mention in mentionees:
                                    try:
                                        profile = cl.getContact(mention['M'])
                                        cl.sendImageWithURL(msg.to,"http://dl.profile.line.naver.jp/"+profile.pictureStatus)
                                    except Exception as e:
                                        pass

                        elif "Getinfo " in msg.text:
                          if msg._from in admin:
                            key = eval(msg.contentMetadata["MENTION"])
                            key1 = key["MENTIONEES"][0]["M"]
                            contact = cl.getContact(key1)
                            image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                            try:
                                cl.sendMessage(msg.to,"Nama:\n" + contact.displayName)
                                cl.sendMessage(msg.to,"Bio:\n" + contact.statusMessage)
                                cl.sendImageWithURL(msg.to,image)
                            except:
                                pass

                        elif msg.text in ["listmid"]: 
                          if msg._from in admin:
                            gruplist = cl.getAllContactIds()
                            kontak = cl.getContacts(gruplist)
                            num=1
                            msgs="╔══[ LIST MID ]"
                            for ids in kontak:
                                msgs+="\n[%i] %s" % (num, ids.mid)
                                num=(num+1)
                            msgs+="\n╚══[ TOTAL FRIEND ]: %i" % len(kontak)
                            cl.sendText(msg.to, msgs)

                        elif cmd == 'listblock':
                          if msg._from in admin:
                            blockedlist = cl.getBlockedContactIds()
                            kontak = cl.getContacts(blockedlist)
                            num=1
                            msgs="List Blocked"
                            for ids in kontak:
                                msgs+="\n[%i] %s" % (num, ids.displayName)
                                num=(num+1)
                            msgs+="\n\nTotal Blocked : %i" % len(kontak)
                           # cl.sendMessage(to, msgs)
                            data = {
                                "type": "text",
                                "text": "{}".format(str(msgs)),
                                "sentBy": {
                                    "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                    "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                    "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                }
                            }
                            cl.postTemplate(to, data)

                        elif "Getbio " in msg.text:
                          if msg._from in admin:
                            key = eval(msg.contentMetadata["MENTION"])
                            key1 = key["MENTIONEES"][0]["M"]
                            contact = cl.getContact(key1)
                            try:
                             #   cl.sendMessage(msg.to,contact.statusMessage)
                                data = {
                                    "type": "text",
                                    "text": "{}".format(str(contact.statusMessage)),
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                            except:
                              #  cl.sendMessage(msg.to,"⟦ʙɪᴏ ᴇᴍᴘᴛʏ⟧")
                                data = {
                                    "type": "text",
                                    "text": "Tidak ada bio",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)

                        elif text.lower() == 'kalender':
                          #if msg._from in admin:
                            tz = pytz.timezone("Asia/Jakarta")
                            timeNow = datetime.now(tz=tz)
                            day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                            hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                            bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                            hr = timeNow.strftime("%A")
                            bln = timeNow.strftime("%m")
                            for i in range(len(day)):
                                if hr == day[i]: hasil = hari[i]
                            for k in range(0, len(bulan)):
                                if bln == str(k): bln = bulan[k-1]
                            readTime = "❂➣ "+ hasil + " : " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\n\n❂➣ Jam : 🔹 " + timeNow.strftime('%H:%M:%S') + " 🔹"
                            #cl.sendMessage(msg.to, readTime)
                            data = {
                                "type": "text",
                                "text": "{}".format(str(readTime)),
                                "sentBy": {
                                    "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                    "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                    "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                }
                            }
                            cl.postTemplate(to, data)

                        elif cmd == "mybot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': mid}
                               cl.sendMessage(msg.to, None, contentMetadata={'mid': mid}, contentType=13)
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': Amid}
                               cl.sendMessage(msg.to, None, contentMetadata={'mid': Amid}, contentType=13)
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': Bmid}
                               cl.sendMessage(msg.to, None, contentMetadata={'mid': Bmid}, contentType=13)
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': Zmid}
                               cl.sendMessage(msg.to, None, contentMetadata={'mid': Zmid}, contentType=13)

                        elif cmd == "myname":
                          if msg._from in admin:
                            contact = cl.getContact(sender)
                           # cl.sendMessage(to, "[ ᴅɪsᴘʟᴀʏ ɴᴀᴍᴇ ]\n{}".format(contact.displayName))
                            data = {
                                "type": "text",
                                "text": "[ ᴅɪsᴘʟᴀʏ ɴᴀᴍᴇ ]\n{}".format(str(contact.displayName)),
                                "sentBy": {
                                    "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                    "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                    "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                }
                            }
                            cl.postTemplate(to, data)

                        elif cmd == "mybio":
                          if msg._from in admin:
                            contact = cl.getContact(sender)
                            #cl.sendMessage(to, "[ sᴛᴀᴛᴜs ʟɪɴᴇ ]\n{}".format(contact.statusMessage))
                            data = {
                                "type": "text",
                                "text": "[ sᴛᴀᴛᴜs ʟɪɴᴇ ]\n{}".format(str(contact.statusMessage)),
                                "sentBy": {
                                    "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                    "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                    "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                }
                            }
                            cl.postTemplate(to, data)

                        elif cmd == "mypicture":
                          if msg._from in admin:
                            contact = cl.getContact(sender)
                            cl.sendImageWithURL(to,"http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus))

                        elif cmd == "myvideo":
                          if msg._from in admin:
                            contact = cl.getContact(sender)
                            cl.sendVideoWithURL(to,"http://dl.profile.line-cdn.net/{}/vp".format(contact.pictureStatus))

                        elif cmd == "mycover":
                          if msg._from in admin:
                            channel = cl.getProfileCoverURL(sender)
                            path = str(channel)
                            cl.sendImageWithURL(to, path)

                        elif "changecover" in msg.text:
                          if msg._from in admin:
                            settings["changeCover"] = True
                            #cl.sendMessage(to, "Send Pict :)")
                            data = {
                                "type": "text",
                                "text": "Send Pict",
                                "sentBy": {
                                    "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                    "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                    "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                }
                            }
                            cl.postTemplate(to, data)

                        elif cmd == "myprofile":
                          if msg._from in admin:
                            text = "~ Profile ~"
                            contact = cl.getContact(sender)
                            cover = cl.getProfileCoverURL(sender)
                            result = "╔══[ Details Profile ]"
                            result += "\n├≽ Display Name : @!"
                            result += "\n├≽ Mid : {}".format(contact.mid)
                            result += "\n├≽ Status Message : {}".format(contact.statusMessage)
                            result += "\n├≽ Picture Profile : http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus)
                            result += "\n├≽ Cover : {}".format(str(cover))
                            result += "\n╚══[ Finish ]"
                            cl.sendImageWithURL(to, "http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus))
                            cl.sendMentionWithFooter(to, text, result, [sender])

                        elif cmd.startswith("block"):
                          if msg._from in admin:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    cl.blockContact(ls)
                                cl.generateReplyMessage(msg.id)
                              #  cl.sendReplyMessage(msg.id, to, "sᴜᴋsᴇs ʙʟᴏᴄᴋ ᴋᴏɴᴛᴀᴋ" + str(contact.displayName) + "ᴍᴀsᴜᴋ ᴅᴀғᴛᴀʀ ʙʟᴏᴄᴋʟɪsᴛ")
                                data = {
                                    "type": "text",
                                    "text": "Success Block\n{}".format(str(contact.displayName)),
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)

                        elif cmd.startswith("addme "):
                          if msg._from in admin:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    cl.findAndAddContactsByMid(ls)
                                cl.generateReplyMessage(msg.id)
                                #cl.sendReplyMessage(msg.id, to, "ʙᴇʀʜᴀsɪʟ ᴀᴅᴅ" + str(contact.displayName) + "ᴋᴜʀɪɴᴇᴍ ᴅᴜʟᴜ ʏᴀᴄʜ")
                                data = {
                                    "type": "text",
                                    "text": "Success Addme\n{}".format(str(contact.displayName)),
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)

                        elif "Getmid " in msg.text:
                            if 'MENTION' in msg.contentMetadata.keys() != None:
                                names = re.findall(r'@(\w+)', msg.text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                for mention in mentionees:
                                    try:
                                       # cl.sendMessage(msg.to,str(mention['M']))
                                        data = {
                                            "type": "text",
                                            "text": "{}".format(str(mention['M'])),
                                            "sentBy": {
                                                "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                                "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                                "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                            }
                                        }
                                        cl.postTemplate(to, data)
                                    except Exception as e:
                                        pass

                        elif "Contact: " in msg.text:
                           if msg._from in admin:
                              mmid = msg.text.replace("Contact: ","")
                              msg.contentType = 13
                              msg.contentMetadata = {"mid":mmid}
                              cl.sendMessage(msg.to, None, contentMetadata={'mid': mmid}, contentType=13)
                              path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                              image = 'http://dl.profile.line.naver.jp'+path
                              cl.sendImageWithURL(msg.to, image)

                        elif cmd.startswith("kontak"):
                          if msg._from in admin:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    cl.sendContact(to,str(ls))

                        elif cmd.startswith("ppvideo"):
                          if msg._from in admin:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    path = "http://dl.profile.line.naver.jp/{}/vp".format(contact.pictureStatus)
                                    cl.sendVideoWithURL(to, str(path))

                        elif text.lower() == "santet mantan":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   cl.removeAllMessages(op.param2)
                                 #  cl.sendMessage(msg.to,"succes delete mantan")
                                   data = {
                                       "type": "text",
                                       "text": "Mantan berhasil disantet",
                                       "sentBy": {
                                           "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                           "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                           "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                       }
                                   }
                                   cl.postTemplate(to, data)
                               except:
                                   pass

                        elif ("Info " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = cl.getContact(key1)
                               cl.sendMessage(msg.to, "╔══「 User Info 」\n┣[]► Nama : "+str(mi.displayName)+"\n┣[]► Mid : " +key1+"\n┣[]► Status Msg"+str(mi.statusMessage)+ "\n╚══「 Info Finish 」")
                               cl.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)
                               if "videoProfile='{" in str(cl.getContact(key1)):
                                   cl.sendVideoWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath)+'/vp.small')
                               else:
                                   cl.sendImageWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath))

                        elif cmd.startswith("bc: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               tz = pytz.timezone("Asia/Jakarta")
                               timeNow = datetime.now(tz=tz)
                               sep = text.split(" ")
                               pesan = text.replace(sep[0] + " ","")
                               saya = cl.getGroupIdsJoined()
                               for group in saya:
                              #     cl.sendMessage(group,"📢📢 BROADCAST 」📢📢\n" + str(pesan))
                                   data = {
                                       "type": "text",
                                       "text": "   🔇🔇[ʙʀᴏᴀᴅᴄᴀsᴛ]🔇🔇\n\n" + str(pesan)+"\n\n╔══════════════\n╠[]► ᴅᴀᴛᴇ : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\n╠[]► ᴛɪᴍᴇ : "+ datetime.strftime(timeNow,'%H:%M:%S')+"\n╚══════════════",
                                       "sentBy": {
                                           "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                           "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                           "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                       }
                                   }
                                   cl.postTemplate(group, data)

                        elif text.lower() == "mykey":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               cl.sendMessage(msg.to, "key Now「 " + str(wait["keyCommand"]) + " 」")

                        elif cmd.startswith("setkey "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   #cl.sendMessage(msg.to, "ɢᴀɢᴀʟ ɴɢᴜʙᴀʜ ᴋᴇʏ")
                                   data = {
                                       "type": "text",
                                       "text": "ɢᴀɢᴀʟ ɴɢᴜʙᴀʜ ᴋᴇʏ",
                                       "sentBy": {
                                           "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                           "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                           "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                       }
                                   }
                                   cl.postTemplate(to, data)
                               else:
                                   wait["keyCommand"] = str(key).lower()
                                  # cl.sendMessage(msg.to, "sᴜᴋsᴇs ɢᴀɴᴛɪ ᴋᴇʏ「{}」".format(str(key).lower()))
                                   data = {
                                       "type": "text",
                                       "text": "sᴜᴋsᴇs ɢᴀɴᴛɪ ᴋᴇʏ「{}」".format(str(key)),
                                       "sentBy": {
                                           "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                           "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                           "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                       }
                                   }
                                   cl.postTemplate(to, data)

                        elif text.lower() == "resetkey":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               wait["keyCommand"]=""
                               #cl.sendMessage(msg.to, "succes resset key command")
                               data = {
                                   "type": "text",
                                   "text": "Success reset key command",
                                   "sentBy": {
                                       "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                       "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                       "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                   }
                               }
                               cl.postTemplate(to, data)

                        elif cmd == "reboot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               #cl.sendMessage(msg.to, "ʙᴏᴛ ᴋᴇᴍʙᴀʟɪ ᴋᴇsᴇᴍᴜʟᴀ")
                               data = {
                                   "type": "text",
                                   "text": "ʙᴏᴛ ᴋᴇᴍʙᴀʟɪ ᴋᴇsᴇᴍᴜʟᴀ",
                                   "sentBy": {
                                       "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                       "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                       "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                   }
                               }
                               cl.postTemplate(to, data)
                               wait["restartPoint"] = msg.to
                               restartBot()
                              # cl.sendMessage(msg.to, "sɪʟᴀʜᴋᴀɴ sᴇᴛᴛɪɴɢ ᴋᴇᴍʙᴀʟɪ")
                               data = {
                                   "type": "text",
                                   "text": "sɪʟᴀʜᴋᴀɴ sᴇᴛᴛɪɴɢ ᴋᴇᴍʙᴀʟɪ",
                                   "sentBy": {
                                       "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                       "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                       "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                   }
                               }
                               cl.postTemplate(to, data)

                        elif cmd == "byeme":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = cl.getGroup(msg.to)
                                #cl.sendMessage(msg.to, "Bye all "+str(G.name))
                                data = {
                                    "type": "text",
                                    "text": "Bye all "+str(G.name),
                                    "sentBy": {
                                        "label": " ⓢ↳Sᴀᴛʀɪᴀ ʙᴏᴛ ʟɪɴᴇ☂ⓢ",
                                        "iconUrl": "https://www.gambaranimasi.org/data/media/188/animasi-bergerak-naga-0186.gif",
                                        "linkUrl": "line://nv/profilePopup/mid=ubae5d883e99e713711ac0881c04f70f9"
                                    }
                                }
                                cl.postTemplate(to, data)
                                cl.leaveGroup(msg.to)

                        elif cmd == "runtime":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               eltime = time.time() - mulai
                               bot = "╔══「Time Info」\n┣[]► Bot Aktif \n┣[]► " +waktu(eltime)+"\n╚══「Info Done」"
                               #cl.sendMessage(msg.to,bot)
                               data = {
                                   "type": "text",
                                   "text": "{}".format(str(bot)),
                                   "sentBy": {
                                       "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                       "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                       "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                   }
                               }
                               cl.postTemplate(to, data)

                        elif cmd == "listpending":
                          if wait["selfbot"] == True:
                            if msg.toType == 2:
                                group = cl.getGroup(to)
                                ret_ = "╭───「 Pending List 」"
                                no = 0
                                if group.invitee is None or group.invitee == []:
                                    return cl.sendReplyMessage(msg_id, to, "Tidak ada pendingan")
                                else:
                                    for pending in group.invitee:
                                        no += 1
                                        ret_ += "\n├≽ {}. {}".format(str(no), str(pending.displayName))
                                    ret_ += "\n╰───「 Total {} Pending 」".format(str(len(group.invitee)))
                                    #cl.sendReplyMessage(msg_id, to, str(ret_))
                                    data = {
                                        "type": "text",
                                        "text": "{}".format(str(ret_)),
                                        "sentBy": {
                                            "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                            "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                            "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                        }
                                    }
                                    cl.postTemplate(to, data)

                        elif cmd == "listmember":
                          if msg._from in admin:
                            if msg.toType == 2:
                                group = cl.getGroup(to)
                                num = 0
                                ret_ = "╔══[ List Member ]"
                                for contact in group.members:
                                    num += 1
                                    ret_ += "\n╠ {}. {}".format(num, contact.displayName)
                                ret_ += "\n╚══[ Total {} Members]".format(len(group.members))
                                #cl.sendMessage(to, ret_)
                                data = {
                                    "type": "text",
                                    "text": "{}".format(str(ret_)),
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)

                        elif cmd == "ginfo":
                          if msg._from in admin:
                            try:
                                G = cl.getGroup(msg.to)
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                cl.sendMessage(msg.to, "  •⌻「Grup Info」⌻•\n\n Nama Group : {}".format(G.name)+ "\n⏹️ID Group : {}".format(G.id)+ "\n⏹️Pembuat : {}".format(G.creator.displayName)+ "\n⏹️Waktu Dibuat : {}".format(str(timeCreated))+ "\n⏹️Jumlah Member : {}".format(str(len(G.members)))+ "\n⏹️Jumlah Pending : {}".format(gPending)+ "\n⏹️Group Qr : {}".format(gQr)+ "\n⏹️Group Ticket : {}".format(gTicket))
                                cl.sendMessage(msg.to, None, contentMetadata={'mid': G.creator.mid}, contentType=13)
                                cl.sendImageWithURL(msg.to, 'http://dl.profile.line-cdn.net/'+G.pictureStatus)
                            except Exception as e:
                                cl.sendMessage(msg.to, str(e))

                        elif cmd.startswith("infogrup"):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getGroup(group)
                                try:
                                    gCreator = G.creator.displayName
                                except:
                                    gCreator = "Tidak ditemukan"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(danil.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += "╔══「 Info Group 」"
                                ret_ += "\n┣[]► Nama Group : {}".format(G.name)
                                ret_ += "\n┣[]► ID Group : {}".format(G.id)
                                ret_ += "\n┣[]► Pembuat : {}".format(gCreator)
                                ret_ += "\n┣[]► Waktu Dibuat : {}".format(str(timeCreated))
                                ret_ += "\n┣[]► Jumlah Member : {}".format(str(len(G.members)))
                                ret_ += "\n┣[]► Jumlah Pending : {}".format(gPending)
                                ret_ += "\n┣[]► Group Qr : {}".format(gQr)
                                ret_ += "\n┣[]► Group Ticket : {}".format(gTicket)
                                ret_ += "\n╚══「 Info Finish 」"
                                #cl.sendMessage(to, str(ret_))
                                data = {
                                    "type": "text",
                                    "text": "{}".format(str(ret_)),
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                            except:
                                pass

                        elif cmd.startswith("infomem"):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = denal.getGroup(group)
                                no = 0
                                ret_ = ""
                                for mem in G.members:
                                    no += 1
                                    ret_ += "\n┣[]► "+ str(no) + ". " + mem.displayName
                                #cl.sendMessage(to,"╔══「 Group Info 」\n┣[]► Group Name : " + str(G.name) + "\n┣══「Member List」" + ret_ + "\n╚══「Total %i Members」" % len(G.members))
                                data = {
                                    "type": "text",
                                    "text": "╔══「 Group Info 」\n┣[]► Group Name : " + str(G.name) + "\n┣══「Member List」" + ret_ + "\n╚══「Total %i Members」" % len(G.members),
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                            except:
                                pass
                        elif cmd == "friendlist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = cl.getAllContactIds()
                               for i in gid:
                                   G = cl.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠[]► " + str(a) + ". " +G.displayName+ "\n"
                               #cl.sendMessage(msg.to,"╔══[ FRIEND LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Friends ]")
                               data = {
                                   "type": "text",
                                   "text": "╔══[ FRIEND LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Friends ]",
                                   "sentBy": {
                                       "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                       "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                       "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                   }
                               }
                               cl.postTemplate(to, data)

                        elif cmd == "gruplist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = cl.getGroupIdsJoined()
                               for i in gid:
                                   G = cl.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "┣[]► " + str(a) + ". " +G.name+ "\n"
                               #cl.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")
                               data = {
                                   "type": "text",
                                   "text": "╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]",
                                   "sentBy": {
                                       "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                       "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                       "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                   }
                               }
                               cl.postTemplate(to, data)

                        elif cmd == "gurl":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = cl.getGroup(msg.to)
                                   X.preventedJoinByTicket = False
                                   cl.updateGroup(X)
                                gurl = cl.reissueGroupTicket(msg.to)
                                cl.sendMessage(msg.to,"line://ti/g/" + gurl)

                        elif cmd == "open qr":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = cl.getGroup(msg.to)
                                   if X.preventedJoinByTicket == True:
                                       X.preventedJoinByTicket = False
                                       cl.updateGroup(X)
                                gurl = cl.reissueGroupTicket(msg.to)
                                cl.sendMessage(msg.to, "Nama : "+str(X.name)+ "\nUrl grup : http://line.me/R/ti/g/"+gurl)

                        elif cmd == "close qr":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = cl.getGroup(msg.to)
                                   X.preventedJoinByTicket = True
                                   cl.updateGroup(X)
                                   #cl.sendMessage(msg.to, "Url Closed")
                                   data = {
                                       "type": "text",
                                       "text": "Url Closed",
                                       "sentBy": {
                                           "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                           "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                           "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                       }
                                   }
                                   cl.postTemplate(to, data)

                        elif cmd == "reject":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              ginvited = cl.getGroupIdsInvited()
                              if ginvited != [] and ginvited != None:
                                  for gid in ginvited:
                                      cl.rejectGroupInvitation(gid)
                                  #cl.sendMessage(to, "ʙᴇʀʜᴀsɪʟ ᴍᴇɴᴊᴜᴀʟ ɢʀᴏᴜᴘ ᴛᴏᴛᴀʟ {} ᴀʟʜᴀᴍᴅᴜʟɪʟᴀʜ ʟᴀᴋᴜ sᴇᴍᴜᴀ ɢʀᴜᴘɴʏᴀ".format(str(len(ginvited))))
                                  data = {
                                      "type": "text",
                                      "text": "ᴍᴇɴᴊᴜᴀʟ ɢʀᴏᴜᴘ ᴛᴏᴛᴀʟ {} ᴅoɴᴇ ʟᴀᴋᴜ sᴇᴍᴜᴀ ɢʀᴜᴘɴʏᴀ".format(str(len(ginvited))),
                                      "sentBy": {
                                          "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                          "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                          "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                      }
                                  }
                                  cl.postTemplate(to, data)
                              else:
                                 # cl.sendMessage(to, "ᴛɪᴅᴀᴋ ᴀᴅᴀ sɪsᴀ ɢʀᴏᴜᴘ sᴀᴍᴀ sᴇᴋᴀʟɪ")
                                  data = {
                                      "type": "text",
                                      "text": "ᴛɪᴅᴀᴋ ᴀᴅᴀ sɪsᴀ ɢʀᴏᴜᴘ sᴀᴍᴀ sᴇᴋᴀʟɪ",
                                      "sentBy": {
                                          "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                          "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                          "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                      }
                                  }
                                  cl.postTemplate(to, data)
#===========BOT UPDATE============#
                        elif cmd == "updategrup":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if msg.toType == 2:
                                settings["groupPicture"] = True
                                #cl.sendMessage(msg.to,"☛ ᴘʟᴇᴀsᴇ sᴇɴᴅ ᴘɪᴄᴛᴜʀᴇ")
                                data = {
                                    "type": "text",
                                    "text": "☛ ᴘʟᴇᴀsᴇ sᴇɴᴅ ᴘɪᴄᴛᴜʀᴇ",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "myfoto":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["RAfoto"][mid] = True
                                #cl.sendMessage(msg.to,"☛ ᴘʟᴇᴀsᴇ sᴇɴᴅ ᴘɪᴄᴛᴜʀᴇ")
                                data = {
                                    "type": "text",
                                    "text": "☛ ᴘʟᴇᴀsᴇ sᴇɴᴅ ᴘɪᴄᴛᴜʀᴇ",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd.startswith("myname: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = cl.getProfile()
                                profile.displayName = string
                                cl.updateProfile(profile)
                                cl.sendMessage(msg.to,"Nama diganti jadi " + string + "")
                        elif cmd.startswith("jsname: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = cl.getProfile()
                                profile.displayName = string
                                cl.updateProfile(profile)
                                cl.sendMessage(msg.to,"✓sᴜᴄᴄᴇss " + string + "")
                                profile = k1.getProfile()
                                profile.displayName = string
                                k1.updateProfile(profile)
                                k1.sendMessage(msg.to,"✓sᴜᴄᴄᴇss " + string + "")
                                profile = k2.getProfile()
                                profile.displayName = string
                                k2.updateProfile(profile)
                                k2.sendMessage(msg.to,"✓sᴜᴄᴄᴇss " + string + "")
                                profile = sw.getProfile()
                                profile.displayName = string
                                sw.updateProfile(profile)
                                sw.sendMessage(msg.to,"✓sᴜᴄᴄᴇss " + string + "")
                                
                        elif cmd == "ajsfoto":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["changePicture"] = True
                                cl.sendMessage(msg.to,"📷 Kirim Fotonya...")

                        elif cmd == "stay":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    ginfo = cl.getGroup(msg.to)
                                    cl.inviteIntoGroup(msg.to, [Amid,Bmid,Zmid])
                                    cl.sendMessage(msg.to,"[ ɴᴀᴍᴀ ɢʀᴏᴜᴘ ]\n"+str(ginfo.name)+"\nᴅᴏɴᴇ ᴋɪᴄᴋᴇʀ ᴀᴋᴛɪᴠᴇ ᴊs")
                                except:
                                    pass             
                        elif cmd == "js out":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = cl.getGroup(msg.to)
                                k1.sendMessage(msg.to, "Pamit "+str(G.name))
                                k2.sendMessage(msg.to, "Pamit "+str(G.name))
                                sw.sendMessage(msg.to, "Pulang dulu "+str(G.name))
                                k1.leaveGroup(msg.to)
                                k2.leaveGroup(msg.to)
                                sw.leaveGroup(msg.to)
                        elif cmd == "js in":
                          if msg._from in admin:
                           if msg.toType == 2:
                               group = cl.getGroup(to)
                               group.preventedJoinByTicket = False
                               cl.updateGroup(group)
                               invsend = 0
                               ticket = cl.reissueGroupTicket(to)
                               k1.acceptGroupInvitationByTicket(to,format(str(ticket)))
                               k2.acceptGroupInvitationByTicket(to,format(str(ticket)))
                               sw.acceptGroupInvitationByTicket(to,format(str(ticket)))
                               time.sleep(0.01)
                        elif msg.text in ["Js absen"]:
                            if msg._from in admin:
                                X = cl.getGroup(msg.to)
                                X.preventedJoinByTicket = False
                                cl.updateGroup(X)
                                invsend = 0
                                Ticket = cl.reissueGroupTicket(msg.to)
                                k1.acceptGroupInvitationByTicket(msg.to,Ticket)
                                k2.acceptGroupInvitationByTicket(msg.to,Ticket)
                                sw.acceptGroupInvitationByTicket(msg.to,Ticket)
                                k1.sendMessage(to,"╠❂➢ᴛʜᴀɴᴋᴢ ʙᴏsᴋᴜ")
                                k2.sendMessage(to,"╠❂➢ᴛʜᴀɴᴋᴢ ʙᴏsᴋᴜ")
                                sw.sendMessage(to,"╠❂➢ᴛʜᴀɴᴋᴢ ʙᴏsᴋᴜ")
                                G = k1.getGroup(msg.to)
                                G = k2.getGroup(msg.to)
                                G = sw.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                k1.updateGroup(G)
                                k2.updateGroup(G)
                                sw.updateGroup(G)
                                k1.sendMessage(to,"╠❂➢ᴋᴀᴍɪ ᴘᴀᴍɪᴛ ʟᴀɢɪ ʙᴏs\n╠❂➢sᴛᴀʏ ᴅɪʟᴜᴀʀ sᴀᴊᴀ\n╠❂➢ᴇᴍᴍᴜᴜᴜᴜᴜᴀᴄᴄʜ")
                                k2.sendMessage(to,"╠❂➢ᴋᴀᴍɪ ᴘᴀᴍɪᴛ ʟᴀɢɪ ʙᴏs\n╠❂➢sᴛᴀʏ ᴅɪʟᴜᴀʀ sᴀᴊᴀ\n╠❂➢ᴇᴍᴍᴜᴜᴜᴜᴜᴀᴄᴄʜ")
                                sw.sendMessage(to,"╠❂➢ᴋᴀᴍɪ ᴘᴀᴍɪᴛ ʟᴀɢɪ ʙᴏs\n╠❂➢sᴛᴀʏ ᴅɪʟᴜᴀʀ sᴀᴊᴀ\n╠❂➢ᴇᴍᴍᴜᴜᴜᴜᴜᴀᴄᴄʜ")
                                Ticket = k1.reissueGroupTicket(msg.to)
                                Ticket = k2.reissueGroupTicket(msg.to)
                                Ticket = sw.reissueGroupTicket(msg.to)
                                k1.sendMessage(msg.to,"╠❂➢  ʙʏᴇ ʙʏᴇ ғᴀᴍs "+str(G.name))
                                k2.sendMessage(msg.to,"╠❂➢  ʙʏᴇ ʙʏᴇ ғᴀᴍs "+str(G.name))
                                sw.sendMessage(msg.to,"╠❂➢  ʙʏᴇ ʙʏᴇ ғᴀᴍs "+str(G.name))
                                k1.leaveGroup(msg.to)
                                k2.leaveGroup(msg.to)
                                sw.leaveGroup(msg.to)
                                cl.inviteIntoGroup(op.param1, [Amid,Bmid,Zmid])
                        elif msg.text in ["Js kickall"]:
                            if msg._from in admin:
                                X = cl.getGroup(msg.to)
                                X.preventedJoinByTicket = False
                                cl.updateGroup(X)
                                invsend = 0
                                Ticket = cl.reissueGroupTicket(msg.to)
                                k1.acceptGroupInvitationByTicket(msg.to,Ticket)
                                k2.acceptGroupInvitationByTicket(msg.to,Ticket)
                                sw.acceptGroupInvitationByTicket(msg.to,Ticket)
                                group = k1.getGroup(msg.to)
                                group = k2.getGroup(msg.to)
                                group = sw.getGroup(msg.to)
                                targets = [contact.mid for contact in group.members]
                                for target in targets:
                                    time.sleep(0.2)
                                    if target not in Bots:
                                        if target not in admin:
                                            try:
                                                k1.kickoutFromGroup(msg.to,[target])
                                                k2.kickoutFromGroup(msg.to,[target])
                                                sw.kickoutFromGroup(msg.to,[target])
                                            except:
                                                pass
                                G = k1.getGroup(msg.to)
                                G = k2.getGroup(msg.to)
                                G = sw.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                k1.updateGroup(G)
                                k2.updateGroup(G)
                                sw.updateGroup(G)
                                Ticket = k1.reissueGroupTicket(msg.to)
                                Ticket = k2.reissueGroupTicket(msg.to)
                                Ticket = sw.reissueGroupTicket(msg.to)
                                k1.leaveGroup(msg.to)
                                k2.leaveGroup(msg.to)
                                sw.leaveGroup(msg.to)
                                cl.inviteIntoGroup(op.param1, [Amid,Bmid,Zmid])
                        elif msg.text in ["Js cancel"]:
                            if msg._from in admin:
                                X = cl.getGroup(msg.to)
                                X.preventedJoinByTicket = False
                                cl.updateGroup(X)
                                invsend = 0
                                Ticket = cl.reissueGroupTicket(msg.to)
                                k1.acceptGroupInvitationByTicket(msg.to,Ticket)
                                k2.acceptGroupInvitationByTicket(msg.to,Ticket)
                                sw.acceptGroupInvitationByTicket(msg.to,Ticket)
                                group = k1.getGroup(msg.to)
                                group = k2.getGroup(msg.to)
                                group = sw.getGroup(msg.to)
                                targets = [contact.mid for contact in group.invitee]
                                for target in targets:
                                    time.sleep(0.4)
                                    if target not in Bots:
                                        if target not in admin:
                                            try:
                                                k1.cancelGroupInvitation(msg.to,[target])
                                                k2.cancelGroupInvitation(msg.to,[target])
                                                sw.cancelGroupInvitation(msg.to,[target])
                                            except:
                                                pass
                                G = k1.getGroup(msg.to)
                                G = k2.getGroup(msg.to)
                                G = sw.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                k1.updateGroup(G)
                                k2.updateGroup(G)
                                sw.updateGroup(G)
                                Ticket = k1.reissueGroupTicket(msg.to)
                                Ticket = k2.reissueGroupTicket(msg.to)
                                Ticket = sw.reissueGroupTicket(msg.to)
                                k1.sendMessage(msg.to, "╠❂➢ʙʏᴇ ʙʏᴇ ғᴀᴍs "+str(G.name))
                                k2.sendMessage(msg.to, "╠❂➢ʙʏᴇ ʙʏᴇ ғᴀᴍs "+str(G.name))
                                sw.sendMessage(msg.to, "╠❂➢ʙʏᴇ ʙʏᴇ ғᴀᴍs "+str(G.name))
                                k1.leaveGroup(msg.to)
                                k2.leaveGroup(msg.to)
                                sw.leaveGroup(msg.to)
                                cl.inviteIntoGroup(op.param1, [Amid,Bmid,Zmid])
#============Comen Tag=========
                        elif cmd in ('rondo','tagall','critt'):
                              if msg._from in admin:
                                try:group = cl.getGroup(to);midMembers = [contact.mid for contact in group.members]
                                except:group = cl.getRoom(to);midMembers = [contact.mid for contact in group.contacts]
                                midSelect = len(midMembers)//20
                                for mentionMembers in range(midSelect+1):
                                    no = 0
                                    ret_ = "╭━━━━━╦════════╦━━━━━╮\n│╭━━━━━━━━━━━━━━━━━━━╮\n╠❂࿇➢A̸͟͞B̸͟͞S̸͟͞E̸͟͞N̸͟͞ P̸͟͞A̸͟͞R̸͟͞A̸͟͞ J̸͟͞O̸͟͞N̸͟͞E̸͟͞S̸͟͞\n│╰━━━━━━━━━━━━━━━━━━━╯\n│╭━━━━━━━━━━━━━━━━━━━╮"
                                    dataMid = []
                                    if msg.toType == 2:
                                        for dataMention in group.members[mentionMembers*20 : (mentionMembers+1)*20]:
                                            dataMid.append(dataMention.mid)
                                            no += 1
                                            ret_ += "\n"+"╠❂➢ {}. @!".format(str(no))
                                        ret_ += "\n│╰━━━━━━━━━━━━━━━━━━━╯\n│╭━━━━━━━━━━━━━━━━━━━╮\n╠❂࿇➢T̸͟͞O̸͟͞T̸͟͞A̸͟͞L̸͟͞ :🎏{}🎏J̸͟͞O̸͟͞N̸͟͞E̸͟͞S̸͟͞\n│╰━━━━━━━━━━━━━━━━━━━╯\n╰━━━━━╩════════╩━━━━━╯".format(str(len(dataMid)))
                                        cl.sendReplyMention(msg_id, to, ret_, dataMid)
                                    else:
                                        for dataMention in group.contacts[mentionMembers*20 : (mentionMembers+1)*20]:
                                            dataMid.append(dataMention.mid)
                                            no += 1
                                            ret_ += "\n"+"╠❂➢ {}. @!".format(str(no))
                                        ret_ += "\n│╰━━━━━━━━━━━━━━━━━━━━╯\n│╭━━━━━━━━━━━━━━━━━━━╮\n╠❂࿇➢T̸͟͞O̸͟͞T̸͟͞A̸͟͞L̸͟͞ :🎏{}🎏J̸͟͞O̸͟͞N̸͟͞E̸͟͞S̸͟͞\n│╰━━━━━━━━━━━━━━━━━━━━╯\n╰━━━━━╩════════╩━━━━━╯".format(str(len(dataMid)))
                                        cl.sendReplyMention(msg_id, to, ret_, dataMid)
                        elif cmd == "hem" or text.lower() == 'desah':
                           if wait["selfbot"] == True:
                            if msg._from in admin:
                             group = cl.getGroup(msg.to)
                            nama = [contact.mid for contact in group.members]
                            k = len(nama)//20
                            for a in range(k+1):
                                txt = u''
                                s=0
                                b=[]
                                for i in group.members[a*20 : (a+1)*20]:
                                    b.append({"S":str(s), "E" :str(s+6), "M":i.mid})
                                    s += 7
                                    txt += u'@Zero \n'
                                cl.sendMessage(msg.to, text=txt, contentMetadata={u'MENTION': json.dumps({'MENTIONEES':b})}, contentType=0)

                        elif cmd == "antijs on":
                          if wait["selfbot"] == True:
                                cl.sendMessage(msg.to,"ɢʀᴜᴘ ᴀɴᴅᴀ ᴀᴍᴀɴ ᴅᴀʀɪ ᴊs ᴋʟᴏ ʀᴀᴛᴀ ʏᴀ ʙɪᴋɪɴ ʟᴀɢɪ ᴡᴋᴡᴋᴡᴋᴋ")
                                data = {
                                    "type": "text",
                                    "text": "{}".format(str(txt)),
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "byeme":
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin:
                                G = cl.getGroup(msg.to)
                                #cl.sendMessage(msg.to, "Bye bye friend\nketemu lain waktu"+str(G.name))
                                data = {
                                    "type": "text",
                                    "text": "Sampai Jumpa{}".format(str(G.name)),
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                     }
                                }
                                cl.postTemplate(to, data)
                                cl.leaveGroup(msg.to)

                        elif cmd == "speed" or cmd == "sp":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                               start = time.time()
                               cl.sendMessage("u3b07c57b6239e5216aa4c7a02687c86d", '.')
                               elapsed_time = time.time() - start
                               cl.sendMessage(msg.to, "%s s" % (elapsed_time))

                        elif cmd == "lurk on":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                 tz = pytz.timezone("Asia/Jakarta")
                                 timeNow = datetime.now(tz=tz)
                                 wait['readPoint'][msg.to] = msg_id
                                 wait['readMember'][msg.to] = {}
                                 cl.sendMessage(msg.to, "Lurking berhasil diaktifkan\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")

                        elif cmd == "lurk off":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                 tz = pytz.timezone("Asia/Jakarta")
                                 timeNow = datetime.now(tz=tz)
                                 del wait['readPoint'][msg.to]
                                 del wait['readMember'][msg.to]
                                 cl.sendMessage(msg.to, "Lurking berhasil dinoaktifkan\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")

                        elif cmd == "lurkers":
                          if msg._from in admin:
                            if msg.to in wait['readPoint']:
                                if wait['readMember'][msg.to] != {}:
                                    aa = []
                                    for x in wait['readMember'][msg.to]:
                                        aa.append(x)
                                    try:
                                        arrData = ""
                                        textx = "  [ Result {} member ]    \n  [ Lurkers ]\n1. ".format(str(len(aa)))
                                        arr = []
                                        no = 1
                                        b = 1
                                        for i in aa:
                                            b = b + 1
                                            end = "\n"
                                            mention = "@x\n"
                                            slen = str(len(textx))
                                            elen = str(len(textx) + len(mention) - 1)
                                            arrData = {'S':slen, 'E':elen, 'M':i}
                                            arr.append(arrData)
                                            tz = pytz.timezone("Asia/Jakarta")
                                            timeNow = datetime.now(tz=tz)
                                            textx += mention
                                            if no < len(aa):
                                                no += 1
                                                textx += str(b) + ". "
                                            else:
                                                try:
                                                    no = "[ {} ]".format(str(cl.getGroup(msg.to).name))
                                                except:
                                                    no = "  "
                                        msg.to = msg.to
                                        msg.text = textx+"\n⌬ Tanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\n⌚ Jam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]"
                                        msg.contentMetadata = {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}
                                        msg.contentType = 0
                                        cl.sendMessage1(msg)
                                    except:
                                        pass
                                    try:
                                        del wait['readPoint'][msg.to]
                                        del wait['readMember'][msg.to]
                                    except:
                                        pass
                                    wait['readPoint'][msg.to] = msg.id
                                    wait['readMember'][msg.to] = {}
                                else:
                                    cl.sendMessage(msg.to, "User kosong...")
                            else:
                                cl.sendMessage(msg.to, "Ketik lurking on ")

                        elif cmd == "sider on":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              try:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                 # cl.sendMessage(msg.to, "╔══════════════\n╠[]► sɪᴅᴇʀ ᴅɪʜɪᴅᴜᴘᴋᴀɴ\n╚══════════════\n╔══════════════\n╠[]► ᴅᴀᴛᴇ : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\n╠[]► ᴛɪᴍᴇ"+ datetime.strftime(timeNow,'%H:%M:%S')+"\n╚══════════════")
                                  data = {
                                      "type": "text",
                                      "text": "╔══════════════\n╠[]► sɪᴅᴇʀ ᴅɪʜɪᴅᴜᴘᴋᴀɴ\n╚══════════════\n╔══════════════\n╠[]► ᴅᴀᴛᴇ : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\n╠[]► ᴛɪᴍᴇ : "+ datetime.strftime(timeNow,'%H:%M:%S')+"\n╚══════════════",
                                      "sentBy": {
                                          "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                          "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                          "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                      }
                                  }
                                  cl.postTemplate(to, data)
                                  del cctv['point'][msg.to]
                                  del cctv['sidermem'][msg.to]
                                  del cctv['cyduk'][msg.to]
                              except:
                                  pass
                              cctv['point'][msg.to] = msg.id
                              cctv['sidermem'][msg.to] = ""
                              cctv['cyduk'][msg.to]=True

                        elif cmd == "sider off":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              if msg.to in cctv['point']:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctv['cyduk'][msg.to]=False
                                 # cl.sendMessage(msg.to, "╔══════════════\n╠[]► sɪᴅᴇʀ ᴅɪᴍᴀᴛɪᴋᴀɴ\n╚══════════════\n╔══════════════\n╠[]► ᴅᴀᴛᴇ : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\n╠[]► ᴛɪᴍᴇ"+ datetime.strftime(timeNow,'%H:%M:%S')+"\n╚══════════════")
                                  data = {
                                      "type": "text",
                                      "text": "╔══════════════\n╠[]► sɪᴅᴇʀ ᴅɪᴍᴀᴛɪᴋᴀɴ\n╚══════════════\n╔══════════════\n╠[]► ᴅᴀᴛᴇ : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\n╠[]► ᴛɪᴍᴇ : "+ datetime.strftime(timeNow,'%H:%M:%S')+"\n╚══════════════",
                                      "sentBy": {
                                          "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                          "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                          "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                      }
                                  }
                                  cl.postTemplate(to, data)
                              else:
                                 # cl.sendMessage(msg.to, "╔══════════════\n╠[]► sɪᴅᴇʀ ᴅɪ ᴏғғ\n╚══════════════")
                                  data = {
                                      "type": "text",
                                      "text": "╔══════════════\n╠[]► sɪᴅᴇʀ ᴅɪ ᴏғғ\n╚══════════════",
                                      "sentBy": {
                                          "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                          "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                          "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                      }
                                  }
                                  cl.postTemplate(to, data)
                                  
#=========== [ Hiburan] ============#
                        elif cmd.startswith("cctv metro"):
                          if msg._from in admin:
                            ret_ = "Daftar Cctv Pantura\n"
                            ret_ += "248 = Alternatif - Cibubur\n119 = Ancol - bandara\n238 = Asia afrika - Bandung"
                            ret_ += "\n276 = Asia afrika - Sudirman\n295 = Bandengan - kota\n294 = Bandengan - Selatan"
                            ret_ += "\n102 = Buncit raya\n272 = Bundaran - HI\n93 = Cideng barat\n289 = Cikini raya"
                            ret_ += "\n175 = Ciloto - Puncak\n142 = Daan mogot - Grogol\n143 = Daan mogot - Pesing"
                            ret_ += "\n204 = Mangga besar\n319 = Margaguna raya\n326 = Margonda raya\n309 = Mas Mansyur - Tn. Abang"
                            ret_ += "\n64 = Matraman\n140 = Matraman - Salemba\n284 = Metro Pdk. Indah\n191 = MT Haryono - Pancoran\n160 = Pancoran barat"
                            ret_ += "\n331 = Pejompongan - Slipi\n332 = Pejompongan - Sudirman\n312 = Perempatan pramuka\n171 = Permata hijau - Panjang"
                            ret_ += "\n223 = Pramuka - Matraman\n222 = Pramuka raya\n314 = Pramuka raya - jl. Tambak\n313 = Pramuka - Salemba raya\n130 = Puncak raya KM84"
                            ret_ += "\n318 = Radio dalam raya\n328 = RS Fatmawati - TB\n274 = Senayan city\n132 = Slipi - Palmerah\n133 = Slipi - Tomang"
                            ret_ += "\n162 = S Parman - Grogol\n324 = Sudirman - Blok M\n18 = Sudirman - Dukuh atas\n325 = Sudirman - Semanggi\n112 = Sudirman - Setiabudi"
                            ret_ += "\n246 = Sudirman - Thamrin\n320 = Sultan agung - Sudirman\n100 = Suryo pranoto\n220 = Tanjung duren\n301 = Tol kebon jeruk"
                            ret_ += "\n41 = Tomang/Simpang\n159 = Tugu Pancoran\n205 = Yos Sudarso - Cawang\n206 = Yos Sudarso - Tj. Priuk"
                            ret_ += "\nUntuk melihat cctv,\nKetik Lihat (Nomer)"                            
                           # cl.sendMessage(to, ret_)
                            data = {
                                "type": "text",
                                "text": "{}".format(str(ret_)),
                                "sentBy": {
                                    "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                    "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                    "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                }
                            }
                            cl.postTemplate(to, data)

                        elif cmd.startswith("lihat"):
                          if msg._from in admin:
                            sep = msg.text.split(" ")
                            cct = msg.text.replace(sep[0] + " ","")
                            with requests.session() as s:
                                s.headers['user-agent'] = 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
                                r = s.get("http://lewatmana.com/cam/{}/bundaran-hi/".format(urllib.parse.quote(cct)))
                                soup = BeautifulSoup(r.content, 'html5lib')
                                try:
                                    ret_ = "LIPUTAN CCTV TERKINI \nDaerah "
                                    ret_ += soup.select("[class~=cam-viewer-title]")[0].text
                                    ret_ += "\nCctv update per 5 menit"
                                    vid = soup.find('source')['src']
                                    ret = "Ketik Lihat nomer cctv selanjutnya"
                                    #cl.sendMessage(to, ret_)
                                    data = {
                                        "type": "text",
                                        "text": "{}".format(str(ret_)),
                                        "sentBy": {
                                            "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                            "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                            "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                        }
                                    }
                                    cl.postTemplate(to, data)
                                    cl.sendVideoWithURL(to, vid)
                                except:
                                   # cl.sendMessage(to, "🚦Data cctv tidak ditemukan!")
                                    data = {
                                        "type": "text",
                                        "text": "🚦Data cctv tidak ditemukan!",
                                        "sentBy": {
                                            "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                            "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                            "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                        }
                                    }
                                    cl.postTemplate(to, data)

                        elif cmd.startswith("imgfood: "):
                          if msg._from in admin:
                                query = msg.text.replace("img food: ","")
                                r = requests.get("https://cryptic-ridge-9197.herokuapp.com/api/imagesearch/" + query + "?offset=1")
                                data=r.text
                                data=json.loads(r.text)
                                if data != []:
                                    for food in data:
                                        cl.sendImageWithURL(msg.to, str(food["url"]))                              
                        elif cmd.startswith("mp4: "):
                            try:
                                sep = msg.text.split(" ")
                                textToSearch = msg.text.replace(sep[0] + " ","")
                                query = urllib.parse.quote(textToSearch)
                                search_url="https://www.youtube.com/results?search_query="
                                mozhdr = {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'}
                                sb_url = search_url + query
                                sb_get = requests.get(sb_url, headers = mozhdr)
                                soupeddata = BeautifulSoup(sb_get.content, "html.parser")
                                yt_links = soupeddata.find_all("a", class_ = "yt-uix-tile-link")
                                x = (yt_links[1])
                                yt_href =  x.get("href")
                                yt_href = yt_href.replace("watch?v=", "")
                                qx = "https://youtu.be" + str(yt_href)
                                vid = pafy.new(qx)
                                stream = vid.streams
                                best = vid.getbest()
                                best.resolution, best.extension
                                for s in stream:
                                    me = best.url
                                    hasil = ""
                                    author = '🔰ᴬᵁᵀᴼᴿ: ' + str(vid.author)
                                    durasi = '\n🔰ᴰᵁᴿᴬˢᴵ: ' + str(vid.duration)
                                    suka = '\n🔰ᴸᴵᴷᴱˢ: ' + str(vid.likes)
                                    rating = '\n🔰ᴿᴬᵀᴵᴺᴳ: ' + str(vid.rating)
                                data = {
                                    "type": "text",
                                    "text": author+ durasi+ suka+ rating,
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                                cl.sendVideoWithURL(msg.to, me)
                            except Exception as e:
                                cl.sendMessage(msg.to,str(e))

                        elif cmd.startswith("mp3: "):
                            try:
                                sep = msg.text.split(" ")
                                textToSearch = msg.text.replace(sep[0] + " ","")
                                query = urllib.parse.quote(textToSearch)
                                search_url="https://www.youtube.com/results?search_query="
                                mozhdr = {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'}
                                sb_url = search_url + query
                                sb_get = requests.get(sb_url, headers = mozhdr)
                                soupeddata = BeautifulSoup(sb_get.content, "html.parser")
                                yt_links = soupeddata.find_all("a", class_ = "yt-uix-tile-link")
                                x = (yt_links[1])
                                yt_href =  x.get("href")
                                yt_href = yt_href.replace("watch?v=", "")
                                qx = "https://youtu.be" + str(yt_href)
                                vid = pafy.new(qx)
                                stream = vid.streams
                                best = vid.getbest()
                                best.resolution, best.extension
                                for s in stream:
                                    me = best.url
                                data = {
                                    "type": "text",
                                    "text": "Audio sedang proses",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                                cl.sendAudioWithURL(msg.to, me)
                            except Exception as e:
                                cl.sendMessage(msg.to,str(e))
                        elif cmd.startswith("clone "):
                           if msg._from in admin:
                             if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                for mention in mentionees:
                                    contact = mention["M"]
                                    break
                                try:
                                    cl.cloneContactProfile(contact)
                                    ryan = cl.getContact(contact)
                                    zx = ""
                                    zxc = ""
                                    zx2 = []
                                    xpesan =  "「 Clone Profile 」\nTarget nya "
                                    ret_ = "Berhasil clone profile target"
                                    ry = str(ryan.displayName)
                                    pesan = ''
                                    pesan2 = pesan+"@x \n"
                                    xlen = str(len(zxc)+len(xpesan))
                                    xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                    zx2.append(zx)
                                    zxc += pesan2
                                    text = xpesan + zxc + ret_ + ""
                                    cl.sendMessage(to, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                except:
                                    cl.sendMessage(msg.to, "Gagal clone profile")
                        elif text.lower() == 'restore':
                           if msg._from in admin:
                              try:
                                  clProfile.displayName = str(myProfile["displayName"])
                                  clProfile.statusMessage = str(myProfile["statusMessage"])
                                  clProfile.pictureStatus = str(myProfile["pictureStatus"])
                                  cl.updateProfileAttribute(8, clProfile.pictureStatus)
                                  cl.updateProfile(clProfile)
                                  cl.sendMessage(msg.to, sender, "「 Restore Profile 」\nNama ", " \nBerhasil restore profile")
                              except:
                                  cl.sendMessage(msg.to, "Gagal restore profile")

                        elif cmd.startswith("smule "):
                            proses = text.split(" ")
                            urutan = text.replace(proses[0] + " ","")
                            count = urutan.split(" ")
                            search = str(count[0])
                            r = requests.get("https://www.smule.com/"+search+"/performances/json")
                            data = json.loads(r.text)
                            if len(count) == 1:
                                no = 0
                                ret_ = "╔══[ ✯ ʟɪsᴛsᴍᴜʟᴇ ✯ ]"
                                for aa in data["list"]:
                                    no += 1
                                    ret_ += "\n╠•➣" + str(no) + ". " + str(aa["title"])
                                ret_ += "\n╚══[ ✯ʟɪsᴛsᴍᴜʟᴇ✯ ]"
                                ret_ += "\nsmule {} nomor ".format(str(search))
                                data = {
                                    "type": "text",
                                    "text": "{}".format(str(ret_)),
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                            elif len(count) == 2:
                                try:
                                    num = int(count[1])
                                    b = data["list"][num - 1]
                                    smule = str(b["web_url"])
                                    c = "\n╠•➣ᴊᴜᴅᴜʟ ʟᴀɢᴜ: "+str(b["title"])
                                    c += "\n╠•➣ᴄʀᴇᴀᴛᴏʀ: "+str(b["owner"]["handle"])
                                    c += "\n╠•➣ʟɪᴋᴇ: "+str(b["stats"]["total_loves"])+" like"
                                    c += "\n╠•➣ᴄᴏᴍᴍᴇɴᴛ: "+str(b["stats"]["total_comments"])+" comment"
                                    c += "\n╠•➣sᴛᴀᴛᴜs ᴏᴄ: "+str(b["message"])
                                    c += "\n╠•➣ᴅɪ ᴅᴇɴɢᴀʀᴋᴀɴ: {}".format(b["stats"]["total_listens"])+" orang"
                                    c += "\n╚══[ ✯ᴡᴀɪᴛ ᴀᴜᴅɪᴏ ᴏʀ ᴠɪᴅᴇᴏ✯ ]"
                                    hasil = "╔══[ ✯ ᴅᴇᴛᴀɪʟsᴍᴜʟᴇ ✯ ]"+str(c)
                                    dl = str(b["cover_url"])
                                    cl.sendImageWithURL(msg.to,dl)
                                    cl.sendReplyMessage(msg.id,msg.to, hasil, {'AGENT_NAME': ' URL Smule','AGENT_LINK': 'https://www.smule.com/{}'.format(str(b['owner']['handle'])),'AGENT_ICON': 'https://png.icons8.com/color/50/000000/speaker.png' })
                                    with requests.session() as s:
                                        s.headers['user-agent'] = 'Mozilla/5.0'
                                        r = s.get("https://sing.salon/smule-downloader/?url=https://www.smule.com{}".format(urllib.parse.quote(smule)))
                                        data = BeautifulSoup(r.content, 'html5lib')
                                        get = data.select("a[href*=https://www.smule.com/redir?]")[0]
                                        title = data.findAll('h2')[0].text
                                        imag = data.select("img[src*=https://www.smule.com/redir?]")[0]
                                        if 'Smule.m4a' in get['download']:
                                            cl.sendAudioWithURL(msg.to, get['href'])
                                        else:
                                            cl.sendVideoWithURL(msg.to, get['href'])
                                except Exception as e:
                                    cl.sendReplyMessage(msg.id,msg.to,"Result Error:\n"+str(e))
#===========COMEN PANGGILAN======
                        elif cmd.startswith("spamtag: "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                wait["limit"] = num
                                cl.sendMessage(msg.to,"Total Spamtag Diubah Menjadi " +strnum)
                        elif cmd.startswith("spamcall: "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                wait["limit"] = num
                                cl.sendMessage(msg.to,"Total Spamcall Diubah Menjadi " +strnum)
                        elif cmd.startswith("spamtag "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                if 'MENTION' in msg.contentMetadata.keys()!=None:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    zx = ""
                                    zxc = " "
                                    zx2 = []
                                    pesan2 = "@a"" "
                                    xlen = str(len(zxc))
                                    xlen2 = str(len(zxc)+len(pesan2)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':key1}
                                    zx2.append(zx)
                                    zxc += pesan2
                                    msg.contentType = 0
                                    msg.text = zxc
                                    lol = {'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                                    msg.contentMetadata = lol
                                    jmlh = int(wait["limit"])
                                    if jmlh <= 1000:
                                        for x in range(jmlh):
                                            try:
                                                cl.sendMessage1(msg)
                                            except Exception as e:
                                                cl.sendText(msg.to,str(e))
                                    else:
                                        data = {
                                            "type": "text",
                                            "text": "Jumlah melebihi 1000",
                                            "sentBy": {
                                                "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                                "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                                "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                            }
                                        }
                                        cl.postTemplate(to, data)
                        elif msg.text.lower().startswith("naik "):
                          if msg._from in admin:
                           if 'MENTION' in msg.contentMetadata.keys()!= None:
                               names = re.findall(r'@(\w+)', text)
                               mention = eval(msg.contentMetadata['MENTION'])
                               mentionees = mention['MENTIONEES']
                               lists = []
                               for mention in mentionees:
                                   if mention["M"] not in lists:
                                       lists.append(mention["M"])
                               for ls in lists:
                                   contact = cl.getContact(ls)                          
                                   jmlh = int(wait["limit"])
                                   data = {
                                       "type": "text",
                                       "text": "Succes {} Spam Call Grup".format(str(wait["limit"])),
                                       "sentBy": {
                                           "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                           "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                           "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                       }
                                   }
                                   cl.postTemplate(to, data)
                                   if jmlh <= 1000:
                                     for x in range(jmlh):
                                         try:
                                             mids = [contact.mid]
                                             cl.acquireGroupCallRoute(msg.to)
                                             cl.inviteIntoGroupCall(msg.to,mids)
                                         except Exception as e:
                                             cl.sendMessage(msg.to,str(e))
                                     else:
                                         cl.sendMessage(msg.to,"")
                        elif cmd == "spamcall":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                             if msg.toType == 2:
                                group = cl.getGroup(to)
                                members = [mem.mid for mem in group.members]
                                jmlh = int(wait["limit"])
                               # cl.sendMessage(msg.to, "Berhasil mengundang {} undangan Call Grup".format(str(wait["limit"])))
                                data = {
                                    "type": "text",
                                    "text": "Done {} Spamcall Grup".format(str(wait["limit"])),
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                                if jmlh <= 1000:
                                  for x in range(jmlh):
                                     try:
                                        call.acquireGroupCallRoute(to)
                                        call.inviteIntoGroupCall(to, contactIds=members)
                                     except Exception as e:
                                        cl.sendText(msg.to,str(e))
                                else:
                                    #cl.sendMessage(msg.to,"Jumlah melebihi batas")
                                    data = {
                                        "type": "text",
                                        "text": "Jumlah melebihi batas",
                                        "sentBy": {
                                            "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                            "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                            "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                        }
                                    }
                                    cl.postTemplate(to, data)

#==========Comen Spam==={{{
                        elif 'Gift: ' in msg.text:
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              korban = msg.text.replace('Gift: ','')
                              korban2 = korban.split()
                              midd = korban2[0]
                              jumlah = int(korban2[1])
                              if jumlah <= 1000:
                                  for var in range(0,jumlah):
                                      cl.sendMessage(midd, None, contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '6'}, contentType=9)
                        elif 'Spam: ' in msg.text:
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              korban = msg.text.replace('Spam: ','')
                              korban2 = korban.split()
                              midd = korban2[0]
                              jumlah = int(korban2[1])
                              if jumlah <= 1000:
                                  for var in range(0,jumlah):
                                      cl.sendMessage(midd, str(Setmain["RAmessage1"]))
                        elif 'ID line: ' in msg.text:
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              msgs = msg.text.replace('ID line: ','')
                              conn = cl.findContactsByUserid(msgs)
                              if True:
                                  cl.sendMessage(msg.to, "http://line.me/ti/p/~" + msgs)
                                  cl.sendMessage(msg.to, None, contentMetadata={'mid': conn.mid}, contentType=13)
#===========Protection============#
                        elif 'Welcome ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Welcome ','')
                              if spl == 'on':
                                  if msg.to in welcome:
                                       msgs = "╠☛ Status : Sudah Di Aktifkan\n╚══「Info Done success」"
                                  else:
                                       welcome.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "┣[]► Status : Di Aktifkan\n┣[]► Group name : \n╠☛ " +str(ginfo.name)+"\n╚══「Done success」"
                                  #cl.sendMessage(msg.to, "╔══「Welcome msg mode on」\n" + msgs)
                                  data = {
                                      "type": "text",
                                      "text": "╔══「Welcome mode on」\n{}".format(str(msgs)),
                                      "sentBy": {
                                          "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                          "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                          "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                      }
                                  }
                                  cl.postTemplate(to, data)
                              elif spl == 'off':
                                    if msg.to in welcome:
                                         welcome.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "┣[]► Status : Di NonAktifkan\n┣[]► Group name : \n╠☛ " +str(ginfo.name)+"\n╚══「Done success」"
                                    else:
                                         msgs = "╠☛ Status : Sudah Di NonAktifkan\n╚══「Info Done success」"
                                    #cl.sendMessage(msg.to, "╔══「Welcome msg mode off」\n" + msgs)
                                    data = {
                                        "type": "text",
                                        "text": "╔══「Welcome mode off」\n{}".format(str(msgs)),
                                        "sentBy": {
                                            "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                            "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                            "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                        }
                                    }
                                    cl.postTemplate(to, data)

                        elif ("Kick" in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in admin:
                                       try:
                                       	cl.kickoutFromGroup(msg.to,[target])
                                       except:
                                           cl.sendMessage(msg.to,"Sorry kaki saya struk..")
                        elif ("Crot" in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Bots:
                                       try:
                                           G = cl.getGroup(msg.to)
                                           G.preventedJoinByTicket = False
                                           cl.updateGroup(G)
                                           invsend = 0
                                           Ticket = cl.reissueGroupTicket(msg.to)
                                           k1.acceptGroupInvitationByTicket(msg.to,Ticket)
                                           k1.kickoutFromGroup(msg.to, [target])
                                           k1.leaveGroup(msg.to)
                                           cl.inviteIntoGroup(op.param1, [Amid])
                                           X = cl.getGroup(msg.to)
                                           X.preventedJoinByTicket = True
                                           cl.updateGroup(X)
                                       except:
                                           k1.sendMessage(to, "Kakiku Struk Boss")
                        elif cmd == "pas band" or text.lower() == '.goo':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               group = cl.getGroup(msg.to)
                               if group.invitee is None:
                                   cl.sendMessage(op.message.to, "Kosong.....")
                               else:
                                   nama = [contact.mid for contact in group.invitee]
                                   for x in nama:
                                     if x not in admin:
                                       klist=[Amid,Bmid,Zmid]
                                       k1.cancelGroupInvitation(msg.to, [x])
                                       k2.cancelGroupInvitation(msg.to, [x])
                                       sw.cancelGroupInvitation(msg.to, [x])
                                       time.sleep(0.00001)
                                       print (msg.to, [x])
                          if msg._from in admin:
                                gs = cl.getGroup(msg.to)
                                targets = []
                                for x in gs.members:
                                    targets.append(x.mid)
                                for a in admin:
                                    if a in targets:
                                        try:
                                            targets.remove(a)
                                        except:
                                            pass
                                for target in targets:
                                    try:
                                        klist=[Amid,Bmid,Zmid]
                                        k1.kickoutFromGroup(msg.to,[target])
                                        k2.kickoutFromGroup(msg.to,[target])
                                        sw.kickoutFromGroup(msg.to,[target])
                                        time.sleep(0.00001)
                                        print (msg.to,[g.mid])
                                    except:
                                        pass
                        elif ("Crit" in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Bots:
                                       try:
                                           G = cl.getGroup(msg.to)
                                           G.preventedJoinByTicket = False
                                           cl.updateGroup(G)
                                           invsend = 0
                                           Ticket = cl.reissueGroupTicket(msg.to)
                                           sw.acceptGroupInvitationByTicket(msg.to,Ticket)
                                           sw.kickoutFromGroup(msg.to, [target])
                                           sw.leaveGroup(msg.to)
                                           cl.inviteIntoGroup(op.param1, [Zmid])
                                           X = cl.getGroup(msg.to)
                                           X.preventedJoinByTicket = True
                                           cl.updateGroup(X)
                                       except:
                                           sw.sendMessage(to, "Kakiku Struk Boss")
#=========COMEN RESPON======#
                        elif msg.text in ["Jepit"]:
                            if msg._from in admin:
                                wait["Invi"] = True
                                #cl.sendMessage(msg.to,"sᴇɴᴅ ᴄᴏɴᴛᴀᴄᴛ")
                                data = {
                                    "type": "text",
                                    "text": "╔══════════════\n╠☛ sᴇɴᴅ ᴄᴏɴᴛᴀᴄᴛ\n╚══════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)

                        elif cmd == "respon on" or text.lower() == 'respon on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention"] = True
                                wait["detectMention2"] = False
                                #cl.sendMessage(msg.to,"ᴀᴜᴛᴏ ʀᴇsᴘᴏɴ ᴍᴏᴅᴇ ᴏɴ")
                                data = {
                                    "type": "text",
                                    "text": "╔══════════════\n╠☛ ᴀᴜᴛᴏ ʀᴇsᴘᴏɴ ᴏɴ\n╚══════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "respon2 on" or text.lower() == 'respon2 on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention2"] = True
                                wait["detectMention"] = False
                              #  cl.sendMessage(msg.to,"ᴀᴜᴛᴏ ʀᴇsᴘᴏɴ2 ᴍᴏᴅᴇ ᴏɴ")
                                data = {
                                    "type": "text",
                                    "text": "╔══════════════\n╠☛ ᴀᴜᴛᴏ ʀᴇsᴘᴏɴ² ᴏɴ\n╚══════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "respon off" or text.lower() == 'respon off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention"] = False
                              #  cl.sendMessage(msg.to,"ᴀᴜᴛᴏ ʀᴇsᴘᴏɴ ᴍᴏᴅᴇ ᴏғғ")
                                data = {
                                    "type": "text",
                                    "text": "╔══════════════\n╠☛ ᴀᴜᴛᴏ ʀᴇsᴘᴏɴ ᴏғғ\n╚══════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "respon2 off" or text.lower() == 'respon2 off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention2"] = False
                                #cl.sendMessage(msg.to,"ᴀᴜᴛᴏ ʀᴇsᴘᴏɴ2 ᴍᴏᴅᴇ ᴏғғ")
                                data = {
                                    "type": "text",
                                    "text": "╔══════════════\n╠☛ ᴀᴜᴛᴏ ʀᴇsᴘᴏɴ ᴏғғ\n╚══════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "notag on" or text.lower() == 'notag on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Mentionkick"] = True
                                #cl.sendMessage(msg.to,"ʀᴇsᴘᴏɴ ᴛᴀɢ ᴋɪᴄᴋ ᴍᴏᴅᴇ ᴏɴ")
                                data = {
                                    "type": "text",
                                    "text": "╔══════════════\n╠☛ ᴛᴀɢ ᴋɪᴄᴋ ᴍᴏᴅᴇ ᴏɴ\n╚══════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "notag off" or text.lower() == 'notag off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Mentionkick"] = False
                               # cl.sendMessage(msg.to,"ʀᴇsᴘᴏɴ ᴛᴀɢ ᴋɪᴄᴋ ᴍᴏᴅᴇ ᴏғғ")
                                data = {
                                    "type": "text",
                                    "text": "╔══════════════\n╠☛ ᴛᴀɢ ᴋɪᴄᴋ ᴍᴏᴅᴇ ᴏғғ\n╚══════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "contact on" or text.lower() == 'contact on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = True
                                #cl.sendMessage(msg.to,"ᴄᴏɴᴛᴀᴄᴛ ʀᴇsᴘᴏɴ ᴍᴏᴅᴇ ᴏɴ")
                                data = {
                                    "type": "text",
                                    "text": "╔══════════════\n╠☛ ᴄᴏɴᴛᴀᴄᴛ ʀᴇsᴘᴏɴ ᴏɴ\n╚══════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "contact off" or text.lower() == 'contact off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = False
                                #cl.sendMessage(msg.to,"ᴄᴏɴᴛᴀᴄᴛ ʀᴇsᴘᴏɴ ᴍᴏᴅᴇ ᴏғғ")
                                data = {
                                    "type": "text",
                                    "text": "╔══════════════\n╠☛ ᴄᴏɴᴛᴀᴄᴛ ʀᴇsᴘᴏɴ ᴏғғ\n╚══════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "autojoin on" or text.lower() == 'autojoin on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoin"] = True
                                #cl.sendMessage(msg.to,"ᴀᴜᴛᴏ ᴊᴏɪɴ ɢʀᴏᴜᴘ ᴍᴏᴅᴇ ᴏɴ")
                                data = {
                                    "type": "text",
                                    "text": "╔══════════════\n╠☛ ᴀᴜᴛᴏᴊᴏɪɴ ɢʀᴏᴜᴘ ᴏɴ\n╚══════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "autojoin off" or text.lower() == 'autojoin off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoin"] = False
                               # cl.sendMessage(msg.to,"ᴀᴜᴛᴏ ᴊᴏɪɴ ɢʀᴏᴜᴘ ᴍᴏᴅᴇ ᴏғғ")
                                data = {
                                    "type": "text",
                                    "text": "╔══════════════\n╠☛ ᴀᴜᴛᴏᴊᴏɪɴ ɢʀᴏᴜᴘ ᴏғғ\n╚══════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "autoleave on" or text.lower() == 'autoleave on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = True
                                #cl.sendMessage(msg.to,"ᴀᴜᴛᴏ ʟᴇᴀᴠᴇ ɢʀᴏᴜᴘ ᴍᴏᴅᴇ ᴏɴ")
                                data = {
                                    "type": "text",
                                    "text": "╔══════════════\n╠☛ ᴀᴜᴛᴏʟᴇᴀᴠᴇ ɢʀᴏᴜᴘ ᴏɴ\n╚══════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "autoleave off" or text.lower() == 'autoleave off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = False
                                #cl.sendMessage(msg.to,"ᴀᴜᴛᴏ ʟᴇᴀᴠᴇ ɢʀᴏᴜᴘ ᴍᴏᴅᴇ ᴏғғ")
                                data = {
                                    "type": "text",
                                    "text": "╔══════════════\n╠☛ ᴀᴜᴛᴏʟᴇᴀᴠᴇ ɢʀᴏᴜᴘ ᴏғғ\n╚══════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "autoadd on" or text.lower() == 'autoadd on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = True
                                #cl.sendMessage(msg.to,"ᴀᴜᴛᴏ ᴀᴅᴅ ᴍᴏᴅᴇ ᴏn")
                                data = {
                                    "type": "text",
                                    "text": "╔══════════════\n╠☛ ᴀᴜᴛᴏᴀᴅᴅ ᴍᴏᴅᴇ ᴏɴ\n╚══════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "autoadd off" or text.lower() == 'autoadd off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = False
                                #cl.sendMessage(msg.to,"ᴀᴜᴛᴏ ᴀᴅᴅ ᴍᴏᴅᴇ ᴏғғ")
                                data = {
                                    "type": "text",
                                    "text": "╔══════════════\n╠☛ ᴀᴜᴛᴏᴀᴅᴅ ᴍᴏᴅᴇ ᴏғғ\n╚══════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "sticker on" or text.lower() == 'sticker on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["sticker"] = True
                               # cl.sendMessage(msg.to,"ᴀᴜᴛᴏ ᴅᴇᴛᴇᴄᴛ sᴛɪᴄᴋᴇʀ ᴍᴏᴅᴇ ᴏɴ")
                                data = {
                                    "type": "text",
                                    "text": "╔══════════════\n╠☛ ᴅᴇᴛᴇᴄᴛ sᴛɪᴄᴋᴇʀ ᴏɴ\n╚══════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "sticker off" or text.lower() == 'sticker off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["sticker"] = False
                                #cl.sendMessage(msg.to,"ᴀᴜᴛᴏ ᴅᴇᴛᴇᴄᴛ sᴛɪᴄᴋᴇʀ ᴍᴏᴅᴇ ᴏғғ")
                                data = {
                                    "type": "text",
                                    "text": "╔══════════════\n╠☛ ᴅᴇᴛᴇᴄᴛ sᴛɪᴄᴋᴇʀ ᴏғғ\n╚══════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "jointicket on" or text.lower() == 'jointicket on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["autoJoinTicket"] = True
                                #cl.sendMessage(msg.to,"ᴀᴜᴛᴏ ᴊᴏɪɴ ᴛɪᴄᴋᴇᴛ ᴍᴏᴅᴇ ᴏɴ")
                                data = {
                                    "type": "text",
                                    "text": "╔══════════════\n╠☛ ᴀᴜᴛᴏ ᴊᴏɪɴᴛɪᴄᴋᴇᴛ ᴏɴ\n╚══════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "jointicket off" or text.lower() == 'jointicket off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["autoJoinTicket"] = False
                                #cl.sendMessage(msg.to,"ᴀᴜᴛᴏ ᴊᴏɪɴ ᴛɪᴄᴋᴇᴛ ᴍᴏᴅᴇ ᴏғғ")
                                data = {
                                    "type": "text",
                                    "text": "╔══════════════\n╠☛ ᴀᴜᴛᴏ ᴊᴏɪɴᴛɪᴄᴋᴇᴛ ᴏғғ\n╚══════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "autoblock on" or text.lower() == 'autoblock on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoBlock"] = True
                               # cl.sendMessage(msg.to,"ᴀᴜᴛᴏ ʙʟᴏᴄᴋ ᴄᴏɴᴛᴀᴄᴛ ᴍᴏᴅᴇ ᴏɴ")
                                data = {
                                    "type": "text",
                                    "text": "╔═════════════════\n╠☛ ᴀᴜᴛᴏʙʟᴏᴄᴋ ᴄᴏɴᴛᴀᴄᴛ ᴏɴ\n╚═════════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "autoblock off" or text.lower() == 'autoblock off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoBlock"] = False
                                #cl.sendMessage(msg.to,"ᴀᴜᴛᴏ ʙʟᴏᴄᴋ ᴄᴏɴᴛᴀᴄᴛ ᴍᴏᴅᴇ ᴏғғ")
                                data = {
                                    "type": "text",
                                    "text": "╔═════════════════\n╠☛ ᴀᴜᴛᴏʙʟᴏᴄᴋ ᴄᴏɴᴛᴀᴄᴛ ᴏғғ\n╚═════════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "post on" or text.lower() == 'post on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["checkPost"] = True
                                #cl.sendMessage(msg.to,"ᴀᴜᴛᴏ ʀᴇᴀᴅ ᴘᴏsᴛ ᴍᴏᴅᴇ ᴏɴ")
                                data = {
                                    "type": "text",
                                    "text": "╔══════════════\n╠☛ ᴀᴜᴛᴏ ᴘᴏsᴛ ᴍᴏᴅᴇ ᴏɴ\n╚══════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "post off" or text.lower() == 'post off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["checkPost"] = False
                                #cl.sendMessage(msg.to,"ᴀᴜᴛᴏ ʀᴇᴀᴅ ᴘᴏsᴛ ᴍᴏᴅᴇ ᴏғғ")
                                data = {
                                    "type": "text",
                                    "text": "╔══════════════\n╠☛ ᴀᴜᴛᴏ ᴘᴏsᴛ ᴍᴏᴅᴇ ᴏғғ\n╚══════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "like on" or text.lower() == 'like on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["likeon"] = True
                               # cl.sendMessage(msg.to,"ᴀᴜᴛᴏ ʟɪᴋᴇ ᴘᴏsᴛ ᴍᴏᴅᴇ ᴏɴ")
                                data = {
                                    "type": "text",
                                    "text": "╔══════════════\n╠☛ ᴀᴜᴛᴏ ʟɪᴋᴇ ᴘᴏsᴛ ᴏɴ\n╚══════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "like off" or text.lower() == 'like off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["likeon"] = False
                               # cl.sendMessage(msg.to,"ᴀᴜᴛᴏ ʟɪᴋᴇ ᴘᴏsᴛ ᴍᴏᴅᴇ ᴏғғ")
                                data = {
                                    "type": "text",
                                    "text": "╔══════════════\n╠☛ ᴀᴜᴛᴏ ʟɪᴋᴇ ᴘᴏsᴛ ᴏғғ\n╚══════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "invite on" or text.lower() == 'invite on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["invite"] = True
                                #cl.sendMessage(msg.to, "sɪʟᴀʜᴋᴀɴ ᴋɪʀɪᴍ ᴋᴏɴᴛᴀᴋ'ɴʏᴀ")
                                data = {
                                    "type": "text",
                                    "text": "╔════════════════\n╠☛ sɪʟᴀʜᴋᴀɴ ᴋɪʀɪᴍ ᴋᴏɴᴛᴀᴋ'ɴʏᴀ\n╚═══════════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "invite off" or text.lower() == 'invite off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["invite"] = False
                                #cl.sendMessage(msg.to,"ɪɴᴠɪᴛᴇ ᴠɪᴀ ᴄᴏɴᴛᴀᴄᴛ ᴅɪɴᴏɴᴀᴋᴛɪғᴋᴀɴ")
                                data = {
                                    "type": "text",
                                    "text": "╔════════════════════\n╠☛ ɪɴᴠɪᴛᴇ ᴠɪᴀ ᴄᴏɴᴛᴀᴄᴛ ᴅɪɴᴏɴᴀᴋᴛɪғᴋᴀɴ\n╚════════════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        if cmd == "unsend on":
                            if msg._from in admin:
                                wait["Unsend"] = True
                               # cl.sendMessage(msg.to, "Unsend message mode on")
                                data = {
                                    "type": "text",
                                    "text": "╔══════════════\n╠☛ ᴜɴsᴇɴᴅ ᴍᴇssᴀɢᴇ ᴏɴ\n╚══════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        if cmd == "unsend off":
                            if msg._from in admin:
                                wait["Unsend"] = False
                               # cl.sendMessage(msg.to, "Unsend message mode off")
                                data = {
                                    "type": "text",
                                    "text": "╔══════════════\n╠☛ ᴜɴsᴇɴᴅ ᴍᴇssᴀɢᴇ ᴏғғ\n╚══════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif "autoreject " in msg.text.lower():
                            xpesan = msg.text.lower()
                            xres = xpesan.replace("autoreject ","")
                            if xres == "off":
                                wait['autoReject'] = False
                                #cl.sendMessage(msg.to,"❎Auto Reject already Off")
                                data = {
                                    "type": "text",
                                    "text": "╔═════════════════\n╠☛ ᴀᴜᴛᴏʀᴇᴊᴇᴄᴛ ᴀʟʀᴇᴀᴅʏ ᴏғғ\n╚═════════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                            elif xres == "on":
                                wait['autoReject'] = True
                                #cl.sendMessage(msg.to,"✅Auto Reject already On")
                                data = {
                                    "type": "text",
                                    "text": "╔═════════════════\n╠☛ ᴀᴜᴛᴏʀᴇᴊᴇᴄᴛ ᴀʟʀᴇᴀᴅʏ ᴏɴ\n╚═════════════════",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
#==================================#
                        elif cmd == "refresh" or text.lower() == 'seger':
                            if msg._from in owner or msg._from in admin or msg._from in staff:
                                wait["addadmin"] = False
                                wait["delladmin"] = False
                                wait["addstaff"] = False
                                wait["dellstaff"] = False
                                wait["addbots"] = False
                                wait["dellbots"] = False
                                wait["wblacklist"] = False
                                wait["dblacklist"] = False
                                wait["Talkwblacklist"] = False
                                wait["Talkdblacklist"] = False
                                cl.sendMessage(msg.to,"Clean..")
                              #  cl.sendMessage(msg.to,"Refresh done 💯")
                                data = {
                                    "type": "text",
                                    "text": "Refresh done 💯",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
#===========ADMIN ADD============#
                        elif ("Adminadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           admin.append(target)
                                           cl.sendMessage(msg.to,"✅Berhasil menambahkan admin")
                                       except:
                                           pass
                        elif ("Staffadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           staff.append(target)
                                           cl.sendMessage(msg.to,"✅Berhasil menambahkan staff")
                                       except:
                                           pass
                        elif ("Admindell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Saints:
                                       try:
                                           admin.remove(target)
                                           cl.sendMessage(msg.to,"✅Berhasil menghapus admin")
                                       except:
                                           pass
                        elif ("Staffdell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Saints:
                                       try:
                                           staff.remove(target)
                                           cl.sendMessage(msg.to,"✅Berhasil menghapus admin")
                                       except:
                                           pass
                                           
                                           #addbots for 7 bots

                        elif cmd == "addasis":
                            try:
                                cl.sendMessage(msg.to, "⏳ᴛᴜɴɢɢᴜ sᴇʟᴀᴍᴀ 5 ᴍᴇɴɪᴛ")
                                cl.findAndAddContactsByMid(Amid)
                                time.sleep(5)
                                cl.findAndAddContactsByMid(Bmid)
                                time.sleep(5)
                                cl.findAndAddContactsByMid(Zmid)
                                time.sleep(5)
                                k1.findAndAddContactsByMid(mid)
                                time.sleep(5)
                                k1.findAndAddContactsByMid(Bmid)
                                time.sleep(5)
                                k1.findAndAddContactsByMid(Zmid)
                                time.sleep(5)
                                k2.findAndAddContactsByMid(mid)
                                time.sleep(5)
                                k2.findAndAddContactsByMid(Amid)
                                time.sleep(5)
                                k2.findAndAddContactsByMid(Zmid)
                                time.sleep(5)
                                sw.findAndAddContactsByMid(mid)
                                time.sleep(5)
                                sw.findAndAddContactsByMid(Amid)
                                time.sleep(5)
                                sw.findAndAddContactsByMid(Bmid)
                                time.sleep(5)
                                cl.sendMessage(to, "✓sᴜᴄᴄᴇss")
                                k1.sendMessage(to, "✓sᴜᴄᴄᴇss")
                                k2.sendMessage(to, "✓sᴜᴄᴄᴇss")
                                sw.sendMessage(to, "✓sᴜᴄᴄᴇss")
                            except:
                                cl.sendMessage(to, "✓sᴜᴄᴄᴇss")
                                k1.sendMessage(to, "✓sᴜᴄᴄᴇss")
                                k2.sendMessage(to, "✓sᴜᴄᴄᴇss")
                                sw.sendMessage(to, "✓sᴜᴄᴄᴇss")
#===========COMMAND BLACKLIST============#

                        elif ("Ban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           wait["blacklist"][target] = True
                                           cl.sendMessage(msg.to,"✅Berhasil menambahkan blacklist")
                                       except:
                                           pass
                        elif ("Unban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del wait["blacklist"][target]
                                           cl.sendMessage(msg.to,"✅Berhasil menghapus blacklist")
                                       except:
                                           pass
                        elif cmd == "ban:on" or text.lower() == 'ban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["wblacklist"] = True
                                cl.sendMessage(msg.to,"📲Kirim kontaknya...")
                        elif cmd == "unban:on" or text.lower() == 'unban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["dblacklist"] = True
                                cl.sendMessage(msg.to,"📲Kirim kontaknya...")
                        elif cmd == "wanted" or text.lower() == 'banlist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                               # cl.sendMessage(msg.to,"Tak ada daftar buronan")
                                data = {
                                    "type": "text",
                                    "text": "Tidak Ada Blacklist",
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["blacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                #cl.sendMessage(msg.to,"〘🔰Ｇr㉫㉫†ⓑⓞⓣ🔰〙Blacklist User\n\n"+ma+"\nTotal「%s」Blacklist User" %(str(len(wait["blacklist"]))))
                                data = {
                                    "type": "text",
                                    "text": "Blacklist User\n"+ma+"\nTotal「%s」Blacklist User" %(str(len(wait["blacklist"]))),
                                    "sentBy": {
                                        "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                        "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                        "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                    }
                                }
                                cl.postTemplate(to, data)
                        elif cmd == "talkbanlist" or text.lower() == 'talkbanlist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["Talkblacklist"] == {}:
                                cl.sendMessage(msg.to,"Tidak ada Talkban user")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["Talkblacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to,"〘🔰Ｇr㉫㉫†ⓑⓞⓣ🔰〙Talkban User\n\n"+ma+"\nTotal「%s」Talkban User" %(str(len(wait["Talkblacklist"]))))
                        elif cmd == "blc" or text.lower() == 'bl':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                   #cl.sendMessage(msg.to,"Tidak ada blacklist")
                                   data = {
                                       "type": "text",
                                       "text": "Tidak ada blacklist",
                                       "sentBy": {
                                           "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                           "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                           "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                       }
                                   }
                                   cl.postTemplate(to, data)
                              else:
                                    ma = ""
                                    for i in wait["blacklist"]:
                                        ma = cl.getContact(i)
                                        cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)
                        elif cmd == "ceban" or text.lower() == 'clearban':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              wait["blacklist"] = {}
                              ragets = cl.getContacts(wait["blacklist"])
                              mc = "「%i」Bersih" % len(ragets)
                           #   cl.sendMessage(msg.to,"✅Buron Berhasil Dibebaskan " +mc)
                              data = {
                                  "type": "text",
                                  "text": "✅Buron Dibebaskan{}".format(str(mc)),
                                  "sentBy": {
                                      "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                      "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                      "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                  }
                              }
                              cl.postTemplate(to, data)
#==========Setting bot========
                        elif 'Set pesan: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set pesan: ','')
                              if spl in [""," ","\n",None]:
                                  #cl.sendMessage(msg.to, "Gagal mengganti Pesan Msg")
                                  data = {
                                      "type": "text",
                                      "text": "Gagal Mengganti Pesan Msg",
                                      "sentBy": {
                                          "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                          "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                          "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                      }
                                  }
                                  cl.postTemplate(to, data)
                              else:
                                  wait["message"] = spl
                                #  cl.sendMessage(msg.to, "「Pesan Msg」\nPesan Msg diganti jadi :\n\n「{}」".format(str(spl)))
                                  data = {
                                      "type": "text",
                                      "text": "「Pesan Msg」\nPesan Msg diganti jadi :\n\n「{}」".format(str(spl)),
                                      "sentBy": {
                                          "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                          "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                          "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                      }
                                  }
                                  cl.postTemplate(to, data)
                        elif 'Set welcome: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set welcome: ','')
                              if spl in [""," ","\n",None]:
                                  #cl.sendMessage(msg.to, "Gagal mengganti Welcome Msg")
                                  data = {
                                      "type": "text",
                                      "text": "Gagal mengganti Welcome Msg",
                                      "sentBy": {
                                          "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                          "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                          "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                      }
                                  }
                                  cl.postTemplate(to, data)
                              else:
                                  wait["welcome"] = spl
                                  #cl.sendMessage(msg.to, "「Welcome Msg」\nWelcome Msg diganti jadi :\n\n「{}」".format(str(spl)))
                                  data = {
                                      "type": "text",
                                      "text": "「Welcome Msg」\nWelcome Msg diganti jadi :\n\n「{}」".format(str(spl)),
                                      "sentBy": {
                                          "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                          "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                          "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                      }
                                  }
                                  cl.postTemplate(to, data)
                                  
                        elif 'Set autoleave: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set autoleave: ','')
                              if spl in [""," ","\n",None]:
                                 # cl.sendMessage(msg.to, "Gagal mengganti Autoleave Msg")
                                  data = {
                                      "type": "text",
                                      "text": "Gagal mengganti Autoleave Msg",
                                      "sentBy": {
                                          "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                          "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                          "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                      }
                                  }
                                  cl.postTemplate(to, data)
                              else:
                                  wait["autoLeave"] = spl
                                  #cl.sendMessage(msg.to, "「Autoleave Msg」\nAutoleave Msg diganti jadi :\n\n「{}」".format(str(spl)))
                                  data = {
                                      "type": "text",
                                      "text": "「Autoleave Msg」\nAutoleave Msg diganti jadi :\n\n「{}」".format(str(spl)),
                                      "sentBy": {
                                          "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                          "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                          "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                      }
                                  }
                                  cl.postTemplate(to, data)
                                  
                        elif 'Set respon: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set respon: ','')
                              if spl in [""," ","\n",None]:
                                  #cl.sendMessage(msg.to, "Gagal mengganti Respon Msg")
                                  data = {
                                      "type": "text",
                                      "text": "Gagal mengganti Respon Msg",
                                      "sentBy": {
                                          "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                          "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                          "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                      }
                                  }
                                  cl.postTemplate(to, data)
                              else:
                                  wait["Respontag"] = spl
                                  #cl.sendMessage(msg.to, "「Respon Msg」\nRespon Msg diganti jadi :\n\n「{}」".format(str(spl)))
                                  data = {
                                      "type": "text",
                                      "text": "「Respon Msg」\nRespon Msg diganti jadi :\n\n「{}」".format(str(spl)),
                                      "sentBy": {
                                          "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                          "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                          "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                      }
                                  }
                                  cl.postTemplate(to, data)
                        elif 'Set respon2: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set respon2: ','')
                              if spl in [""," ","\n",None]:
                                 # cl.sendMessage(msg.to, "Gagal mengganti Respon Msg")
                                  data = {
                                      "type": "text",
                                      "text": "Gagal mengganti Respon Msg",
                                      "sentBy": {
                                          "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                          "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                          "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                      }
                                  }
                                  cl.postTemplate(to, data)
                              else:
                                  wait["Respontag2"] = spl
                                 # cl.sendMessage(msg.to, "「Respon Msg」\nRespon Msg diganti jadi :\n\n「{}」".format(str(spl)))
                                  data = {
                                      "type": "text",
                                      "text": "「Respon Msg」\nRespon Msg diganti jadi :\n\n「{}」".format(str(spl)),
                                      "sentBy": {
                                          "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                          "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                          "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                      }
                                  }
                                  cl.postTemplate(to, data)
                        elif 'Set spam: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set spam: ','')
                              if spl in [""," ","\n",None]:
                                  #cl.sendMessage(msg.to, "Gagal mengganti Spam")
                                  data = {
                                      "type": "text",
                                      "text": "Gagal mengganti Spam",
                                      "sentBy": {
                                          "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                          "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                          "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                      }
                                  }
                                  cl.postTemplate(to, data)
                              else:
                                  Setmain["ARmessage1"] = spl
                               #   cl.sendMessage(msg.to, "「Spam Msg」\nSpam Msg diganti jadi :\n\n「{}」".format(str(spl)))
                                  data = {
                                      "type": "text",
                                      "text": "「Spam Msg」\nSpam Msg diganti jadi :\n\n「{}」".format(str(spl)),
                                      "sentBy": {
                                          "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                          "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                          "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                      }
                                  }
                                  cl.postTemplate(to, data)
                        elif 'Set sider: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set sider: ','')
                              if spl in [""," ","\n",None]:
                                 # cl.sendMessage(msg.to, "Gagal mengganti Sider Msg")
                                  data = {
                                      "type": "text",
                                      "text": "Gagal mengganti Sider Msg",
                                      "sentBy": {
                                          "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                          "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                          "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                      }
                                  }
                                  cl.postTemplate(to, data)
                              else:
                                  wait["mention"] = spl
                                 # cl.sendMessage(msg.to, "「Sider Msg」\nSider Msg diganti jadi :\n\n「{}」".format(str(spl)))
                                  data = {
                                      "type": "text",
                                      "text": "「Sider Msg」\nSider Msg diganti jadi :\n\n「{}」".format(str(spl)),
                                      "sentBy": {
                                          "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                          "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                          "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                      }
                                  }
                                  cl.postTemplate(to, data)
                        elif text.lower() == "cek pesan":
                            if msg._from in admin:
                               #cl.sendMessage(msg.to, "「Pesan Msg」\nPesan Msg mu :\n\n「 " + str(wait["message"]) + " 」")
                               data = {
                                   "type": "text",
                                   "text": "「Pesan Msg」\nPesan Msg mu :\n\n「 " +str(wait["message1"]),
                                   "sentBy": {
                                       "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                       "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                       "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                   }
                               }
                               cl.postTemplate(to, data)
                        elif text.lower() == "cek welcome":
                            if msg._from in admin:
                              # cl.sendMessage(msg.to, "「Welcome Msg」\nWelcome Msg mu :\n\n「 " + str(wait["welcome"]) + " 」")
                               data = {
                                   "type": "text",
                                   "text": "「Welcome Msg」\nWelcome Msg mu :\n\n" + str(wait["welcome"]),
                                   "sentBy": {
                                       "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                       "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                       "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                   }
                               }
                               cl.postTemplate(to, data)
                        elif text.lower() == "cek leave":
                            if msg._from in admin:
                               #cl.sendMessage(msg.to, "「Autoleave Msg」\nAutoleave Msg mu :\n\n「 " + str(wait["autoLeave"]) + " 」")
                               data = {
                                   "type": "text",
                                   "text": "「Autoleave Msg」\nAutoleave Msg mu :\n\n" + str(wait["autoLeave"]),
                                   "sentBy": {
                                       "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                       "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                       "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                   }
                               }
                               cl.postTemplate(to, data)
                        elif text.lower() == "cek respon":
                            if msg._from in admin:
                               #cl.sendMessage(msg.to, "「Respon Msg」\nRespon Msg mu :\n\n「 " + str(wait["Respontag"]) + " 」")
                               data = {
                                   "type": "text",
                                   "text": "「Respon Msg」\nRespon Msg mu :\n\n" + str(wait["Respontag"]),
                                   "sentBy": {
                                       "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                       "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                       "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                   }
                               }
                               cl.postTemplate(to, data)
                        elif text.lower() == "cek respon2":
                            if msg._from in admin:
                               #cl.sendMessage(msg.to, "「Respon Msg」\nRespon Msg mu :\n\n「 " + str(wait["Respontag2"]) + " 」")
                               data = {
                                   "type": "text",
                                   "text": "「Respon Msg」\nRespon Msg mu :\n\n" + str(wait["Respontag2"]),
                                   "sentBy": {
                                       "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                       "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                       "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                   }
                               }
                               cl.postTemplate(to, data)
                        elif text.lower() == "cek spam":
                            if msg._from in admin:
                               #cl.sendMessage(msg.to, "「Spam Msg」\nSpam Msg mu :\n\n「 " + str(setting["RAmessage1"]) + " 」")
                               data = {
                                   "type": "text",
                                   "text": "「Spam Msg」\nSpam Msg mu :\n\n" + str(Setmain["ARmessage1"]),
                                   "sentBy": {
                                       "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                       "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                       "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                   }
                               }
                               cl.postTemplate(to, data)
                        elif text.lower() == "cek sider":
                            if msg._from in admin:
                               #cl.sendMessage(msg.to, "「Sider Msg」\nSider Msg mu :\n\n「 " + str(wait["mention"]) + " 」")
                               data = {
                                   "type": "text",
                                   "text": "「Sider Msg」\nSider Msg mu :\n\n" + str(wait["mention"]),
                                   "sentBy": {
                                       "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                       "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                       "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                   }
                               }
                               cl.postTemplate(to, data)
#===========JOIN TICKET============#
                        elif "/ti/g/" in msg.text.lower():
                          if wait["selfbot"] == True:
                            if msg._from in admin or msg._from in owner:
                              if settings["autoJoinTicket"] == True:
                                 link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                 links = link_re.findall(text)
                                 n_links = []
                                 for l in links:
                                     if l not in n_links:
                                        n_links.append(l)
                                 for ticket_id in n_links:
                                     group = cl.findGroupByTicket(ticket_id)
                                     cl.acceptGroupInvitationByTicket(group.id,ticket_id)
                                     #cl.sendMessage(msg.to, "Masuk : %s" % str(group.name))
                                     data = {
                                         "type": "text",
                                         "text": "Masuk : %s{}".format(str(group.name)),
                                         "sentBy": {
                                             "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                             "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                             "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                         }
                                     }
                                     cl.postTemplate(to, data)
                                   #  group1 = ka.findGroupByTicket(ticket_id)
#===========add img============#                                                                                
                        elif text.lower() == "cekbot":
                            if msg._from in admin:
                               try:cl.inviteIntoGroup(to, ["u45882d0ead1703855dbc60d40e37bec7"]);has = "OK"
                               except:has = "NOT"
                               try:cl.kickoutFromGroup(to, ["u45882d0ead1703855dbc60d40e37bec7"]);has1 = "OK"
                               except:has1 = "NOT"
                               if has == "OK":sil = "⏹️Normal 💯"
                               else:sil = "⏹️Cidera ❎"
                               if has1 == "OK":sil1 = "⏹️Normal 💯"
                               else:sil1 = "⏹️Cidera ❎"
                               data = {
                                   "type": "text",
                                   "text": "🔰Kick: {} \n🔰Invit: {}".format(sil1,sil),
                                   "sentBy": {
                                       "label": " ♀ᴛᴇᴀᴍ ɢʀᴇᴇᴛ ʙᴏᴛs♀",
                                       "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                       "linkUrl": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f"
                                   }
                               }
                               cl.postTemplate(to, data)
#===============HIBURAN============================#
                        elif cmd.startswith("addmp3 "):
                            if msg._from in admin:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name not in audios:
                                    settings["Addaudio"]["status"] = True
                                    settings["Addaudio"]["name"] = str(name.lower())
                                    audios[str(name.lower())] = ""
                                    f = codecs.open("audio.json","w","utf-8")
                                    json.dump(audios, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    cl.sendMessage(msg.to,"Silahkan kirim mp3 nya...") 
                                else:
                                    cl.sendMessage(msg.to, "Mp3 itu sudah dalam list") 
                                
                        elif cmd.startswith("dellmp3 "):
                            if msg._from in admin:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name in audios:
                                    cl.deleteFile(audios[str(name.lower())])
                                    del audios[str(name.lower())]
                                    f = codecs.open("audio.json","w","utf-8")
                                    json.dump(audios, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    cl.sendMessage(msg.to, "Berhasil menghapus mp3 {}".format( str(name.lower())))
                                else:
                                    cl.sendMessage(msg.to, "Mp3 itu tidak ada dalam list") 
                                 
                        elif cmd == "listmp3":
                            if msg._from in admin:
                                no = 0
                                ret_ = "╔═══❲ My Music ❳════\n"
                                for audio in audios:
                                    ret_ += "┣[]◇  " + audio.title() + "\n"
                                ret_ += "╚═══❲ {} Record  ❳════".format(str(len(audios)))
                                cl.sendMessage(to, ret_)

                        elif cmd.startswith("addsticker "):
                            if msg._from in admin:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name not in stickers:
                                    settings["Addsticker"]["status"] = True
                                    settings["Addsticker"]["name"] = str(name.lower())
                                    stickers[str(name.lower())] = ""
                                    f = codecs.open("Sticker.json","w","utf-8")
                                    json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    cl.sendMessage(to, "Silahkan kirim stickernya...") 
                                else:
                                    cl.sendMessage(to, "Sticker itu sudah dalam list") 
                                
                        elif cmd.startswith("dellsticker "):
                            if msg._from in admin:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name in stickers:
                                    del stickers[str(name.lower())]
                                    f = codecs.open("sticker.json","w","utf-8")
                                    json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    cl.sendMessage(to, "Berhasil menghapus sticker {}".format( str(name.lower())))
                                else:
                                    cl.sendMessage(to, "Sticker itu tidak ada dalam list") 
                                                   
                        elif cmd == "liststicker":
                            if msg._from in admin:
                                no = 0
                                ret_ = "╔═══❲ My Sticker ❳════\n"
                                for sticker in stickers:
                                    ret_ += "┣[]◇  " + sticker.title() + "\n"
                                ret_ += "╚═══❲  {} Stickers  ❳════".format(str(len(stickers)))
                                cl.sendMessage(to, ret_)

                        elif cmd.startswith("addimg "):
                            if msg._from in admin:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name not in images:
                                    settings["Addimage"]["status"] = True
                                    settings["Addimage"]["name"] = str(name.lower())
                                    images[str(name.lower())] = ""
                                    f = codecs.open("image.json","w","utf-8")
                                    json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    cl.sendMessage(to, "Silahkan kirim fotonya...")
                                else:
                                    cl.sendMessage(to, "Foto itu sudah dalam list")

                        elif cmd.startswith("dellimg "):
                            if msg._from in admin:
                               sep = text.split(" ")
                               name = text.replace(sep[0] + " ","")
                               name = name.lower()
                               if name in images:
                                   cl.deleteFile(images[str(name.lower())])
                                   del images[str(name.lower())]
                                   f = codecs.open("image.json","w","utf-8")
                                   json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                                   cl.sendMessage(to, "Berhasil menghapus {}".format( str(name.lower())))
                               else:
                                   cl.sendMessage(to, "Foto itu tidak ada dalam list")

                        elif cmd == "listimage":
                            if msg._from in admin:
                                no = 0
                                ret_ = "╭───「 Daftar Image 」\n"
                                for audio in audios:
                                    no += 1
                                    ret_ += str("├≽") + " " + audio.title() + "\n"
                                ret_ += "╰───「 Total {} Image 」".format(str(len(audios)))
                                cl.sendMessage(to, ret_)
#==============add video==========================================================================
                        elif cmd.startswith("addvideo"):
                            if msg._from in admin:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name not in images:
                                    settings["Addvideo"]["status"] = True
                                    settings["Addvideo"]["name"] = str(name.lower())
                                    images[str(name.lower())] = ""
                                    f = codecs.open("video.json","w","utf-8")
                                    json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    cl.sendMessage(to, "Silahkan kirim video nya...")
                                else:
                                    cl.sendMessage(to, "video itu sudah dalam list")
                        elif cmd.startswith("dellvideo "):
                            if msg._from in admin:
                               sep = text.split(" ")
                               name = text.replace(sep[0] + " ","")
                               name = name.lower()
                               if name in images:
                                   cl.deleteFile(images[str(name.lower())])
                                   del images[str(name.lower())]
                                   f = codecs.open("video.json","w","utf-8")
                                   json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                                   cl.sendMessage(to, "Berhasil menghapus {}".format( str(name.lower())))
                               else:
                                   cl.sendMessage(to, "video itu tidak ada dalam list")

                        elif cmd == "listvideo":
                            if msg._from in admin:
                                no = 0
                                ret_ = "╭───「 Daftar Video 」\n"
                                for audio in audios:
                                    no += 1
                                    ret_ += str("├≽") + " " + audio.title() + "\n"
                                ret_ += "╰───「 Total {} Video 」".format(str(len(audios)))
                                cl.sendMessage(to, ret_)
    except Exception as error:
        print (error)


while True:
    try:
        ops = oepoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                bot(op)
                # Don't remove this line, if you wan't get error soon!
                oepoll.setRevision(op.revision)
    except Exception as e:
    	logError(e)                      
